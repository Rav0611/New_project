# Sample Level Metadata Curation for datasets

### Prerequisites
- Docker installed.
- Git LFS installed.

### Steps
1. Clone the repository.
2. Create a `.env` file in the base directory, aka. `sample_curation` with the necessary details:
   ```
   PMC_EMAIL=rajdeep.mondal@elucidata.io
   OPENAI_KEY=<your_openai_api_token>
   POLLY_TOKEN=<your_polly_token>
   WORKSPACE_ID=<your_workspace_id>
   ```
3. Specify GSE IDs in `input/required_dataset_ids.json`:
   ```
   ["GSE5788", "GSE15573", "GSE39452"]
   ```
4. Build the Docker image:
   ```
   docker build -t sample_curation .
   ```
5. Run the Docker container:
   ```
   docker run sample_curation
   ```
6. Check your Polly workspace for the results.

### Please feel free Reach out if there are any issues.

### Limitations and Flexibility

- **Adaptability**: Primarily designed for sample-level curation from GEO. However, its components are configurable for seamless adaptation to various data sources, showcasing the versatility of GPT-based language models in curation tasks.
  
- **Optimization**: Currently this system is Fine-tuned for GEO datasets containing 220 to 250 samples to maintain quality, this range encompasses approximately 98-99% of GEO's datasets. This focus ensures high efficiency and quality curation, with the potential for future enhancements to accommodate larger datasets.
