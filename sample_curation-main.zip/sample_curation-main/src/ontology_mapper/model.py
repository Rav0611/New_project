from enum import Enum
from typing import Optional

from pydantic import BaseModel


class EntityType(str, Enum):
    """
    An enumeration of entity types for biomedical named entity recognition.

    This enumeration defines possible types of entities that can be recognized in biomedical text,
    such as diseases, drugs, tissues, cell lines, cell types, and organisms.
    """

    disease = "disease"
    drug = "drug"
    tissue = "tissue"
    cell_line = "cell_line"
    cell_type = "cell_type"
    organism = "organism"


class Mention(BaseModel):
    """
    A Pydantic model representing a mention with associated keywords, entity type, ontology, and top-k value.

    Attributes:
        keywords (list): A list of keywords associated with the mention.
        entity_type (EntityType): The type of entity the mention represents.
        ontology (str): The ontology to which the entity type belongs.
        topk (int): The number of top candidates to consider for the mention.
    """

    keywords: list
    entity_type: EntityType
    ontology: str
    topk: int


class CandidateInput(BaseModel):
    """
    A Pydantic model representing the input for candidate generation.

    Attributes:
        mention (Mention): The mention for which candidates are to be generated.
        cached_dict (dict): A dictionary containing cached information for entities.
    """

    mention: Mention
    cached_dict: dict


class Term(BaseModel):
    """
    A Pydantic model representing a term with optional candidates and reasoning.

    Attributes:
        name (str): The name of the term.
        candidates (Optional[list]): A list of candidate entities for the term. Defaults to None.
        reasoning (Optional[str]): The reasoning behind the selection of candidates. Defaults to None.
    """

    name: str
    candidates: Optional[list] = None
    reasoning: Optional[str] = None
