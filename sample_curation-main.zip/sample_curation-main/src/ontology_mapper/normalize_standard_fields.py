import gzip
import logging
import pickle

import pronto
import requests
from bs4 import BeautifulSoup

from ontology_mapper.gpt import _get_gpt_predictions
from ontology_mapper.model import CandidateInput
from ontology_mapper.simple_tagger import SimpleTagger
from utils.biosyn import BioSyn

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)

TISSUE_BTO_PATH = (
    "/app/src/ontology_mapping_resources/cached_dicts/cached_dictionary_tissue_bto.gz"
)
DISEASE_MONDO_PATH = "/app/src/ontology_mapping_resources/cached_dicts/cached_dictionary_disease_mondo.gz"
CELL_TYPE_PATH = (
    "/app/src/ontology_mapping_resources/cached_dicts/cached_dictionary_cell_type.gz"
)


# Load pubmed SapBERT model for other entity types
biosyn_pubmed = BioSyn(max_length=50, use_cuda=False, initial_sparse_weight=0)
biosyn_pubmed.load_dense_encoder(
    model_name_or_path="cambridgeltl/SapBERT-from-PubMedBERT-fulltext"
)

biosyn_disease = BioSyn(max_length=50, use_cuda=False)
biosyn_disease.load_model(model_name_or_path="dmis-lab/biosyn-sapbert-ncbi-disease")


def get_candidates(data):
    """
    Retrieves candidate entities for a given mention based on dense and sparse embeddings.

    This function computes the embeddings for the mention's keywords, retrieves the score matrices
    for both dense and sparse embeddings, and combines them using a weighted sum to generate a final
    score matrix. It then retrieves the top-k candidate entities based on the final scores.

    Args:
        data (CandidateInput): An instance of CandidateInput containing the mention and cached dictionary.

    Returns:
        dict: A dictionary mapping each keyword to a list of unique candidate entities sorted by score.

    The function handles different entity types, specifically 'disease', by using a dedicated BioSyn
    instance for diseases. For other entity types, it uses a general BioSyn instance for PubMed. It
    logs errors encountered during the processing of candidate entities.

    Example:
        >>> data = CandidateInput(...)
        >>> candidates = get_candidates(data)
        >>> print(candidates)
        # Output will be a dictionary with keywords as keys and lists of candidate entities as values.
    """

    logger = logging.getLogger("get candidate")
    entity_type = data.mention.entity_type.value
    cached_dict = data.cached_dict

    if entity_type == "disease":

        query_embedding_dense = biosyn_disease.embed_dense(data.mention.keywords)
        query_embedding_sparse = biosyn_disease.embed_sparse(data.mention.keywords)

        sparse_score_matrix = biosyn_disease.get_score_matrix(
            query_embeds=query_embedding_sparse,
            dict_embeds=cached_dict["dict_sparse_embeds"],
        )

        dense_score_matrix = biosyn_disease.get_score_matrix(
            query_embeds=query_embedding_dense,
            dict_embeds=cached_dict["dict_dense_embeds"],
        )
        sparse_weight = biosyn_disease.get_sparse_weight().item()
        score_matrix = sparse_weight * sparse_score_matrix + dense_score_matrix

        candidate_idxs = biosyn_disease.retrieve_candidate(
            score_matrix=score_matrix, topk=data.mention.topk
        )

    else:
        query_embedding_dense = biosyn_pubmed.embed_dense(data.mention.keywords)
        score_matrix = biosyn_pubmed.get_score_matrix(
            query_embeds=query_embedding_dense,
            dict_embeds=cached_dict["dict_dense_embeds"],
        )
        candidate_idxs = biosyn_pubmed.retrieve_candidate(
            score_matrix=score_matrix, topk=data.mention.topk
        )

    ent_to_cand = {}
    for i, keyword in enumerate(data.mention.keywords):
        all_candidates = []
        for cand in candidate_idxs[i]:
            syn = cached_dict["terms"][cand][0]
            try:
                parts = str(cached_dict["terms"][cand][1]).split(":")
                if len(parts) >= 3:
                    name = parts[0]
                    ontology_id = ":".join(parts[1:])
                else:
                    raise ValueError("Not enough parts after splitting by ':'")
            except Exception as e:
                logger.error(
                    f"Error processing string '{cached_dict['terms'][cand][1]}': {e}",
                    exc_info=True,
                )
                continue

            temp = {
                "name": name,
                "id": ontology_id,
                "synonyms": syn,
                "score": score_matrix[0][cand],
            }
            all_candidates.append(temp)
        cand_scores = [
            (x["id"], x["name"], x["score"], x["synonyms"]) for x in all_candidates
        ]
        cand_scores_sorted = sorted(cand_scores, key=lambda x: x[2], reverse=True)
        unique_candidates = list(
            dict.fromkeys([(x[0], x[1]) for x in cand_scores_sorted])
        )
        ent_to_cand[keyword] = unique_candidates
    return ent_to_cand


def load_tissue_obo():
    """
    Loads tissue ontology terms and their synonyms from an OBO file.

    This function reads an OBO (Open Biomedical Ontologies) file to extract tissue terms and their
    synonyms, creating a mapping from each synonym to the corresponding term name. It filters out
    obsolete terms, terms not in the 'tissue' subset, and terms on a blacklist.

    Returns:
        dict: A dictionary mapping from synonym to term name for tissue ontology.

    The function uses the 'pronto' library to parse the OBO file. It applies several filters to
    exclude unwanted terms and then iterates over the terms to populate the mapping dictionary.

    Example:
        >>> name_to_id = load_tissue_obo()
        >>> print(name_to_id['heart'])
        'heart'
        >>> print(name_to_id['cardiac muscle tissue'])
        'heart'
    """

    obo_path = "/app/src/ontology_mapping_resources/obo_files/tissue.obo"
    bto = pronto.Ontology(obo_path)

    blacklist = ["animal", "scale", "serum"]

    bto_terms = filter(lambda t: not t.obsolete, bto.terms())
    bto_terms = filter(lambda t: "tissue" in t.subsets, bto_terms)
    bto_terms = list(filter(lambda t: t.name not in blacklist, bto_terms))

    name_to_id = {}

    # order of these two for loops is important
    for term in bto_terms:
        for syn in list(term.synonyms):
            name_to_id[syn.description] = term.name

    for term in bto_terms:
        name_to_id[term.name] = term.name

    return name_to_id


def load_cell_type_obo():
    """
    Loads cell type ontology terms and their synonyms from an OBO file.

    Returns:
        dict: A dictionary mapping from synonym to term name for cell type ontology.

    The function reads an OBO file to extract cell type terms and their synonyms, excluding
    any terms that are obsolete or on a blacklist. It then creates a mapping from each synonym
    to the corresponding term name.

    Example:
        >>> name_to_id = load_cell_type_obo()
        >>> print(name_to_id['neuron'])
        'neuron'
    """

    obo_path = "/app/src/ontology_mapping_resources/obo_files/cell_type.obo"
    cl = pronto.Ontology(obo_path)

    blacklist = ["cell"]

    cl_terms = filter(lambda t: not t.obsolete, cl.terms())
    cl_terms = list(filter(lambda t: t.name not in blacklist, cl_terms))

    name_to_id = {}

    # order of these two for loops is important
    for term in cl_terms:
        for syn in list(term.synonyms):
            name_to_id[syn.description] = term.name

    for term in cl_terms:
        name_to_id[term.name] = term.name

    return name_to_id


def load_cell_line_obo():
    """
    Loads cell line ontology terms and their synonyms from an OBO file.

    Returns:
        dict: A dictionary mapping from synonym to term name for cell line ontology.

    The function reads an OBO file to extract cell line terms and their synonyms. It creates
    a mapping from each synonym to the corresponding term name, appending " cell" to each
    synonym for consistency.

    Example:
        >>> syn_to_name = load_cell_line_obo()
        >>> print(syn_to_name['HeLa'])
        'HeLa'
    """

    cvcl_path = (
        "/app/src/ontology_mapping_resources/obo_files/cellosaurus-edited-v3.obo"
    )
    cvcl = pronto.Ontology(cvcl_path)

    syn_to_name = {}
    for term in cvcl.terms():
        for syn in term.synonyms:
            syn_to_name[syn.description] = term.name
            syn_to_name[syn.description + " cell"] = term.name
    for term in cvcl.terms():
        syn_to_name[term.name] = term.name
        syn_to_name[term.name + " cell"] = term.name
    return syn_to_name


def load_cached_dict(dict_path):
    """
    Loads a cached dictionary from a gzipped pickle file.

    Args:
        dict_path (str): The file path to the gzipped pickle file containing the dictionary.

    Returns:
        dict: The loaded dictionary.

    The function opens a gzipped pickle file and loads the dictionary contained within it.

    Example:
        >>> cached_dictionary = load_cached_dict('/path/to/cached_dict.pkl.gz')
        >>> print(cached_dictionary.keys())
        # Output will show the keys of the loaded dictionary.
    """

    with gzip.open(dict_path, "rb") as fp:
        cached_dictionary = pickle.load(fp)
    return cached_dictionary


def load_all_cached_dicts():
    """
    Loads all cached dictionaries for disease, tissue, and cell type.

    Returns:
        dict: A dictionary containing cached dictionaries for different entity types.

    The function loads cached dictionaries for disease (MONDO), tissue (BTO), and cell type
    from their respective gzipped pickle files and returns them in a single dictionary.

    Example:
        >>> all_cached_dicts = load_all_cached_dicts()
        >>> print(all_cached_dicts['disease']['mondo'].keys())
        # Output will show the keys of the disease MONDO cached dictionary.
    """

    all_cached_dicts = {
        "disease": {
            "mondo": load_cached_dict(DISEASE_MONDO_PATH),
        },
        "tissue": {"bto": load_cached_dict(TISSUE_BTO_PATH)},
        "cell_type": {"cell": load_cached_dict(CELL_TYPE_PATH)},
    }
    return all_cached_dicts


def _tissue_(ents, cached_dict):
    """
    Normalizes tissue entities using cached dictionary data and GPT predictions.

    This function attempts to normalize tissue mentions by first retrieving candidate entities
    using a cached dictionary. If multiple candidates are found, it uses a GPT model to predict
    the most likely match. The results, including any reasoning provided by the GPT model, are
    compiled into a normalized output.

    Args:
        ents (Mention): A Mention object containing the tissue mentions to be normalized.
        cached_dict (dict): A dictionary containing cached information for tissue entities.

    Returns:
        dict: A dictionary mapping each tissue mention to its normalized tag, reasoning, and
                list of candidates. If an error occurs, an error message is included instead.

    The function logs the progress of normalization and any errors encountered. If there is only
    one candidate for a mention, it is automatically selected as the normalized tag. Otherwise,
    the function relies on GPT predictions to determine the most likely candidate.

    Example:
        >>> ents = Mention(...)
        >>> cached_dict = {...}
        >>> normalized_tissues = _tissue_(ents, cached_dict)
        >>> print(normalized_tissues)
        # Output will be a dictionary with normalized tissue entities and any associated reasoning.
    """

    tissue_logger = logging.getLogger("tissue_normalizer")
    tissue_logger.info("Starting tissue normalization")
    try:
        mention_data = CandidateInput(mention=ents, cached_dict=cached_dict)
        tissue_candidates_with_id = get_candidates(mention_data)
    except Exception as e:
        tissue_logger.error("Failed to get tissue candidates", exc_info=True)
        return {"error": f"Failed to get tissue candidates: {str(e)}"}

    normalized_output = {}
    for index, (key, val) in enumerate(tissue_candidates_with_id.items(), start=1):
        try:
            reasoning = ""
            tissue_candidates = [x[1] for x in val]
            if len(tissue_candidates) == 1:
                tag = tissue_candidates[0]
            else:
                try:
                    gpt_pred = _get_gpt_predictions(
                        mention=key,
                        entity_type="tissue",
                        ontology=ents.ontology,
                        candidates=val,
                        cached_dictionary=cached_dict,
                        model_name="gpt-4-turbo-preview",
                    )
                    tag = gpt_pred.choice
                    reasoning = gpt_pred.reasoning
                except Exception as e:
                    tissue_logger.error(
                        "Failed to get GPT predictions for tissue", exc_info=True
                    )
                    return {
                        "error": f"Failed to get GPT predictions for tissue: {str(e)}"
                    }
            normalized_output[key] = {
                "normalised_tag": tag,
                "reasoning": reasoning,
                "candidates": tissue_candidates,
            }
            tissue_logger.info(
                f"Processed {index}/{len(tissue_candidates_with_id)} tissues: {key}"
            )
        except Exception as e:
            tissue_logger.error(f"Processing failed for tissue {key}", exc_info=True)
            normalized_output[key] = {
                "error": f"Processing failed for tissue {key}: {str(e)}"
            }

    return normalized_output


def get_tax_id(organism_name):
    """
    Retrieves the taxonomy ID for a given organism name from NCBI's taxonomy database.

    Args:
        organism_name (str): The common name of the organism to look up.

    Returns:
        str or None: The taxonomy ID if found, otherwise None.

    The function sends a GET request to NCBI's E-utilities API and parses the JSON response
    to extract the taxonomy ID associated with the organism name.

    Example:
        >>> tax_id = get_tax_id("Homo sapiens")
        >>> print(tax_id)
        '9606'  # Example taxonomy ID for Homo sapiens.
    """

    search_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
    params = {"db": "taxonomy", "term": organism_name, "retmode": "json"}
    search_response = requests.get(search_url, params=params)
    if (
        search_response.status_code == 200
        and search_response.json()["esearchresult"]["idlist"]
    ):
        return search_response.json()["esearchresult"]["idlist"][0]
    return None


def get_scientific_name(tax_id):
    """
    Retrieves the scientific name for a given taxonomy ID from NCBI's taxonomy database.

    Args:
        tax_id (str): The taxonomy ID of the organism.

    Returns:
        str or None: The scientific name if found, otherwise None.

    The function sends a GET request to NCBI's E-utilities API and parses the XML response
    to extract the scientific name associated with the taxonomy ID.

    Example:
        >>> scientific_name = get_scientific_name('9606')
        >>> print(scientific_name)
        'Homo sapiens'  # Example scientific name for taxonomy ID 9606.
    """

    fetch_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/efetch.fcgi"
    params = {"db": "taxonomy", "id": tax_id, "retmode": "xml"}
    fetch_response = requests.get(fetch_url, params=params)
    if fetch_response.status_code == 200:
        soup = BeautifulSoup(fetch_response.content, "lxml")
        sci_name_tag = soup.find("scientificname")
        if sci_name_tag:
            return sci_name_tag.text
    return None


def normalize_organism_name(organism_name):
    """
    Normalizes an organism name to its scientific name using NCBI's taxonomy database.

    Args:
        organism_name (str): The common name of the organism to normalize.

    Returns:
        str or None: The normalized scientific name if found, otherwise None.

    The function first retrieves the taxonomy ID for the given organism name and then
    fetches the scientific name associated with that taxonomy ID.

    Example:
        >>> normalized_name = normalize_organism_name("human")
        >>> print(normalized_name)
        'Homo sapiens'  # Example normalized name for "human".
    """

    tax_id = get_tax_id(organism_name)
    if tax_id:
        scientific_name = get_scientific_name(tax_id)
        return scientific_name
    return None


def _organism_(ents):
    """
    Normalizes organism names within the given Mention object to their scientific names.

    Args:
        ents (Mention): A Mention object containing keywords that represent organism names.

    Returns:
        dict: A dictionary mapping each original organism name to its normalized scientific name.

    The function logs the normalization process, including any errors encountered. It ensures
    that the Mention object contains keywords and then normalizes each keyword.

    Example:
        >>> ents = Mention(keywords=['human', 'mouse'])
        >>> normalized_organisms = _organism_(ents)
        >>> print(normalized_organisms)
        {'human': {'normalised_tag': 'Homo sapiens'}, 'mouse': {'normalised_tag': 'Mus musculus'}}
    """

    organism_logger = logging.getLogger("organism_normalizer")
    organism_logger.info("Starting organism normalization process.")

    if not ents or not hasattr(ents, "keywords"):
        organism_logger.error(
            "The 'ents' parameter is missing or does not have 'keywords'."
        )
        return {}

    if not ents.keywords:
        organism_logger.warning("No keywords to normalize.")
        return {}

    keywords = list(set([x.strip() for x in ents.keywords]))
    normalized_organisms = {}

    for index, organism_name in enumerate(keywords, start=1):
        try:
            normalized_organism_name = normalize_organism_name(organism_name)
            normalized_organisms[organism_name] = {
                "normalised_tag": normalized_organism_name,
            }
            organism_logger.info(
                f"Normalized '{organism_name}' to '{normalized_organism_name}'. Processed {index}/{len(keywords)} organisms."
            )
        except Exception as e:
            organism_logger.error(
                f"Error normalizing '{organism_name}': {e}. Processed {index}/{len(keywords)} organisms."
            )

    organism_logger.info("Organism normalization process completed.")
    return normalized_organisms


def _cell_type_(ents, cached_dict):
    """
    Normalizes cell type entities using cached dictionary data and GPT predictions.

    This function attempts to normalize cell type mentions by first retrieving candidate entities
    using a cached dictionary. If multiple candidates are found, it uses a GPT model to predict
    the most likely match. The results, including any reasoning provided by the GPT model, are
    compiled into a normalized output.

    Args:
        ents (Mention): A Mention object containing the cell type mentions to be normalized.
        cached_dict (dict): A dictionary containing cached information for cell type entities.

    Returns:
        dict: A dictionary mapping each cell type mention to its normalized tag, reasoning, and
                list of candidates. If an error occurs, an error message is included instead.

    The function logs the progress of normalization and any errors encountered. If there is only
    one candidate for a mention, it is automatically selected as the normalized tag. Otherwise,
    the function relies on GPT predictions to determine the most likely candidate.

    Example:
        >>> ents = Mention(...)
        >>> cached_dict = {...}
        >>> normalized_cell_types = _cell_type_(ents, cached_dict)
        >>> print(normalized_cell_types)
        # Output will be a dictionary with normalized cell type entities and any associated reasoning.
    """

    celltype_logger = logging.getLogger("celltype_normalizer")
    celltype_logger.info("Starting cell type normalization")
    try:
        mention_data = CandidateInput(mention=ents, cached_dict=cached_dict)
        celltype_candidates_with_id = get_candidates(mention_data)
    except Exception as e:
        celltype_logger.error("Failed to get cell type candidates", exc_info=True)
        return {"error": f"Failed to get cell type candidates: {str(e)}"}

    normalized_output = {}
    for index, (key, val) in enumerate(celltype_candidates_with_id.items(), start=1):
        try:
            reasoning = ""
            celltype_candidates = [x[1] for x in val]
            if len(celltype_candidates) == 1:
                tag = celltype_candidates[0]
            else:
                try:
                    gpt_pred = _get_gpt_predictions(
                        mention=key,
                        entity_type="cell_type",
                        ontology=ents.ontology,
                        candidates=val,
                        cached_dictionary=cached_dict,
                        model_name="gpt-4-turbo-preview",
                    )
                    tag = gpt_pred.choice
                    reasoning = gpt_pred.reasoning
                except Exception as e:
                    celltype_logger.error(
                        "Failed to get GPT predictions for cell type", exc_info=True
                    )
                    return {
                        "error": f"Failed to get GPT predictions for cell type: {str(e)}"
                    }
            normalized_output[key] = {
                "normalised_tag": tag,
                "reasoning": reasoning,
                "candidates": celltype_candidates,
            }
            celltype_logger.info(
                f"Processed {index}/{len(celltype_candidates_with_id)} cell types: {key}"
            )
        except Exception as e:
            celltype_logger.error(
                f"Processing failed for cell type {key}", exc_info=True
            )
            normalized_output[key] = {
                "error": f"Processing failed for cell type {key}: {str(e)}"
            }

    return normalized_output


def _disease_(ents, cached_dict):
    """
    Normalizes disease entities using cached dictionary data and GPT predictions.

    This function attempts to normalize disease mentions by first retrieving candidate entities
    using a cached dictionary. If multiple candidates are found, it uses a GPT model to predict
    the most likely match. The results, including any reasoning provided by the GPT model, are
    compiled into a normalized output.

    Args:
        ents (Mention): A Mention object containing the disease mentions to be normalized.
        cached_dict (dict): A dictionary containing cached information for disease entities.

    Returns:
        dict: A dictionary mapping each disease mention to its normalized tag, reasoning, and
                list of candidates. If an error occurs, an error message is included instead.

    The function logs the progress of normalization and any errors encountered. If there is only
    one candidate for a mention, it is automatically selected as the normalized tag. Otherwise,
    the function relies on GPT predictions to determine the most likely candidate.

    Example:
        >>> ents = Mention(...)
        >>> cached_dict = {...}
        >>> normalized_diseases = _disease_(ents, cached_dict)
        >>> print(normalized_diseases)
        # Output will be a dictionary with normalized disease entities and any associated reasoning.
    """

    disease_logger = logging.getLogger("disease_normalizer")
    disease_logger.info("Starting disease normalization")
    try:
        mention_data = CandidateInput(mention=ents, cached_dict=cached_dict)
        disease_candidates_with_id = get_candidates(mention_data)
    except Exception as e:
        disease_logger.error("Failed to get candidates", exc_info=True)
        return {"error": f"Failed to get candidates: {str(e)}"}

    normalized_output = {}
    for index, (key, val) in enumerate(disease_candidates_with_id.items(), start=1):
        try:
            reasoning = ""
            disease_candidates = [x[1] for x in val]
            if len(disease_candidates) == 1:
                tag = disease_candidates[0]
            else:
                disease_cand_gpt = val
                try:
                    gpt_pred = _get_gpt_predictions(
                        mention=key,
                        entity_type="disease",
                        ontology=ents.ontology,
                        candidates=disease_cand_gpt,
                        cached_dictionary=cached_dict,
                        model_name="gpt-4-turbo-preview",
                    )
                    tag = gpt_pred.choice
                    reasoning = gpt_pred.reasoning
                except Exception as e:
                    disease_logger.error("Failed to get GPT predictions", exc_info=True)
                    return {"error": f"Failed to get GPT predictions: {str(e)}"}
            normalized_output[key] = {
                "normalised_tag": tag,
                "reasoning": reasoning,
                "candidates": disease_candidates,
            }
            disease_logger.info(
                f"Processed {index}/{len(disease_candidates_with_id)}: {key}"
            )
        except Exception as e:
            disease_logger.error(f"Processing failed for {key}", exc_info=True)
            normalized_output[key] = {"error": f"Processing failed for {key}: {str(e)}"}

    return normalized_output


def _cellline_(ents):
    """
    Normalizes cell line names based on a pre-loaded ontology.

    This function takes a list of cell line names (keywords) from the Mention object, processes them
    to remove the term "cell line" if present, and then attempts to match each processed keyword to
    a cell line name in the pre-loaded ontology. If a match is found, it is included in the list of
    matches; otherwise, "none" is added to indicate no match.

    Args:
        ents (Mention): A Mention object containing keywords that represent cell line names.

    Returns:
        list: A list of normalized cell line names corresponding to the input keywords.

    The function uses a pre-loaded ontology mapping from synonyms to cell line names to find matches.
    It also handles plural forms of cell line names by stripping the trailing "s" and attempting to
    match again.

    Example:
        >>> ents = Mention(keywords=['HeLa cell line', 'Jurkat cells'])
        >>> normalized_cell_lines = _cellline_(ents)
        >>> print(normalized_cell_lines)
        ['HeLa', 'Jurkat']  # Example output with normalized cell line names.
    """

    syn_to_name = load_cell_line_obo()
    keywords = [x.replace("cell line", "").strip() for x in ents.keywords]
    matches = [
        syn_to_name.get(x) or syn_to_name.get(x.rstrip("s")) or "none" for x in keywords
    ]
    matches = [x for x in matches if x is not None]
    return matches


def _normalize_(data):
    """
    Normalizes entities across various types using corresponding cached dictionaries.

    This function iterates over a collection of entities, identifies their types, and applies
    type-specific normalization processes. It supports normalization for tissues, diseases,
    cell lines, cell types, and organisms.

    Args:
        data (list): A list of Mention objects, each containing keywords and an entity type.

    Returns:
        dict: A dictionary with normalized data for each entity type. If an error occurs during
            normalization, an error message is included under the respective entity type.

    The function loads all necessary cached dictionaries for normalization at the start. It then
    processes each entity in the input data, updating the output dictionary with normalized results
    or error messages. The function handles missing dictionaries and other exceptions by logging
    appropriate error messages.

    Example:
        >>> data = [Mention(keywords=['heart'], entity_type=EntityType.tissue, ontology='BTO')]
        >>> normalized_data = _normalize_(data)
        >>> print(normalized_data)
        # Output will be a dictionary with normalized data for 'tissue' and any other entity types present in 'data'.
    """

    try:
        all_cached_dicts = load_all_cached_dicts()
        print("Loaded all cached dictionaries.")
    except Exception as e:
        print(f"Error loading cached dictionaries: {str(e)}")
        return {"error": f"Failed to load cached dictionaries: {str(e)}"}

    output_data = {}
    total_entities = len(data)
    processed_entities = 0

    for ent in list(data):
        processed_entities += 1
        try:
            entity_type = ent.entity_type.value
            print(f"Processing {entity_type} {processed_entities}/{total_entities}.")
        except AttributeError as e:
            print(f"AttributeError: {str(e)}")
            continue

        try:
            if entity_type == "tissue":
                cached_dict = all_cached_dicts["tissue"][ent.ontology.lower()]
                tissue_norm_data = _tissue_(ent, cached_dict)
                output_data.setdefault("tissue", {}).update(tissue_norm_data)

            elif entity_type == "disease":
                cached_dict = all_cached_dicts["disease"][ent.ontology.lower()]
                disease_norm_data = _disease_(ent, cached_dict)
                output_data.setdefault("disease", {}).update(disease_norm_data)

            elif entity_type == "cell_line":
                normalized_celllines = _cellline_(ent)
                cellline_norm_data = {
                    k: v for k, v in zip(ent.keywords, normalized_celllines)
                }
                output_data.setdefault("cell_line", {}).update(cellline_norm_data)

            elif entity_type == "cell_type":
                cached_dict = all_cached_dicts["cell_type"][ent.ontology.lower()]
                celltype_norm_data = _cell_type_(ent, cached_dict)
                output_data.setdefault("cell_type", {}).update(celltype_norm_data)

            elif entity_type == "organism":
                organism_norm_data = _organism_(ent)
                output_data.setdefault("organism", {}).update(organism_norm_data)

        except KeyError as e:
            error_message = f"Missing dictionary for {entity_type}: {str(e)}"
            print(error_message)
            output_data[entity_type] = {"error": error_message}
        except Exception as e:
            error_message = f"Normalization failed for {entity_type}: {str(e)}"
            print(error_message)
            output_data[entity_type] = {"error": error_message}

    print("Normalization process completed.")
    return output_data
