import os

import openai
from dotenv import load_dotenv
from langchain.llms import OpenAI
from langchain.output_parsers import PydanticOutputParser
from langchain.prompts import PromptTemplate
from pydantic import BaseModel, Field

load_dotenv()

openai.api_key = os.getenv("OPENAI_KEY")

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_KEY")


class Choice(BaseModel):
    """
    A Pydantic model representing a choice with its associated score and reasoning.

    This model is used to define the structure of a choice, which includes the term name that
    best matches a query, a similarity score indicating the strength of the match, and a
    reasoning that explains why the match was made.

    Attributes:
        choice (str): The term name that has the highest match with the query.
        score (float): A numerical similarity score representing the match quality.
        reasoning (str): A textual explanation of the reasoning behind the match.

    The Pydantic model enforces type checking and validation for the attributes. The `Field`
    function is used to add descriptions to the model's fields, which can be useful for
    generating documentation or schema definitions.

    Example:
        >>> choice_instance = Choice(choice='Seizure', score=0.95, reasoning='The term matches the symptoms described.')
        >>> print(choice_instance)
        # Output will be an instance of Choice with the specified attributes and values.
    """

    choice: str = Field(description="highest matched term name")
    score: float = Field(description="a similarity score")
    reasoning: str = Field(description="reasoning for the match")


def get_def_syn(ontology, ontology_id, cached_dictionary):
    """
    Retrieves the definition and synonyms for a given ontology ID from the cached dictionary.

    This function looks up the definition and synonyms for an ontology ID based on the specified
    ontology. It handles different ontology prefixes and retrieves the relevant information from
    the cached dictionary.

    Args:
        ontology (str): The name of the ontology to which the ontology ID belongs.
        ontology_id (str): The ontology ID for which the definition and synonyms are to be retrieved.
        cached_dictionary (dict): A dictionary containing definitions and synonyms for ontology IDs.

    Returns:
        tuple: A tuple containing two elements:
            - definition (str): The definition of the ontology term.
            - synonyms (list of str): A list of synonyms for the ontology term.

    The function supports multiple ontologies such as MESH, HDO, MONDO, BTO, and CELL. It adjusts
    the ontology ID with the appropriate prefix before looking it up in the cached dictionary.

    Example:
        >>> ontology = "MESH"
        >>> ontology_id = "D012345"
        >>> cached_dictionary = {
                "descriptor_def": {
                    "D012345": {
                        "definition": "A condition characterized by...",
                        "synonyms": ["Condition A", "Condition B"]
                    }
                }
            }
        >>> definition, synonyms = get_def_syn(ontology, ontology_id, cached_dictionary)
        >>> print(definition)
        'A condition characterized by...'
        >>> print(synonyms)
        ['Condition A', 'Condition B']
    """

    definition = ""
    synonyms = []
    if ontology == "MESH":
        if "D" in ontology_id:
            definition = cached_dictionary["descriptor_def"][ontology_id]["definition"]
            synonyms = cached_dictionary["descriptor_def"][ontology_id]["synonyms"]
        else:
            if cached_dictionary["supplementary_def"].get(ontology_id):
                definition = cached_dictionary["supplementary_def"][ontology_id][
                    "definition"
                ]
                synonyms = cached_dictionary["supplementary_def"][ontology_id][
                    "synonyms"
                ]
    else:
        if ontology == "HDO":
            ontology_id = "DOID:" + ontology_id
        if ontology == "MONDO":
            ontology_id = "MONDO:" + ontology_id
        if ontology == "BTO":
            ontology_id = "BTO:" + ontology_id
        if ontology == "CELL":
            ontology_id = "CL:" + ontology_id

        if cached_dictionary["descriptors"].get(ontology_id):
            definition = cached_dictionary["descriptors"][ontology_id]["definition"]
            synonyms = cached_dictionary["descriptors"][ontology_id]["synonyms"]
    return definition, synonyms


def get_context_from_dict(ontology, candidates, cached_dictionary):
    """
    Constructs strings of candidate entities and their definitions from a given ontology and cached dictionary.

    This function iterates over a list of candidate entities, retrieves their definitions and synonyms
    from the cached dictionary, and formats this information into two strings: one listing the candidates
    and the other providing detailed definitions and synonyms for each candidate.

    Args:
        ontology (str): The ontology from which the candidates are derived.
        candidates (list of tuples): A list where each tuple contains an ontology ID and the term it represents.
        cached_dictionary (dict): A dictionary that maps ontology IDs to their definitions and synonyms.

    Returns:
        tuple: A tuple containing three elements:
            - candidate_str (str): A string listing all candidate terms with their index numbers.
            - definition_str (str): A string providing definitions and synonyms for each candidate term.
            - i (int): The index of the last candidate in the list.

    The function uses a helper function `get_def_syn` to retrieve the definition and synonyms for each
    candidate term based on the ontology ID. It then formats this information into the two strings.

    Example:
        >>> ontology = "Human Phenotype Ontology"
        >>> candidates = [("HP:0001250", "Seizure"), ("HP:0004323", "Short stature")]
        >>> cached_dictionary = {"HP:0001250": ("A seizure is...", ["convulsion", "fit"])}
        >>> candidate_str, definition_str, i = get_context_from_dict(ontology, candidates, cached_dictionary)
        >>> print(candidate_str)
        '0. Seizure;\n1. Short stature;\n'
        >>> print(definition_str)
        'Seizure:\n\tDefinition: A seizure is...\n\tSynonyms: convulsion, fit\n\nShort stature:\n\t'
    """

    candidate_str = ""
    definition_str = ""
    for i, cand in enumerate(candidates):
        ontology_id = cand[0]
        term = cand[1]
        definition, synonyms = get_def_syn(ontology, ontology_id, cached_dictionary)

        temp_cand_str = f"{i}. {term};\n"
        candidate_str += temp_cand_str

        if definition != "":
            temp_def_str = (
                f"{term}:\n\tDefinition: {definition}\n\tSynonymns: {synonyms}\n\n"
            )
            definition_str += temp_def_str
        else:
            temp_def_str = f"{term}:\n\t{definition}"
            definition_str += temp_def_str
    return candidate_str, definition_str, i


template_prompt = """You have been provided with a {entity_type} name extracted from an RNASeq experiment dataset sample, along with a list of normalized terms. Each term is accompanied by a description and possible synonyms from the {ontology} ontology.

Extracted {entity_type}: '{mention}'

Options:
{candidate_str}
{i}. None
    
    
Context:
{definition_str}

Task:
Your task is to find the option that has the highest match with the given {entity_type} mention, considering the provided contexts. Provide a reasoning with a similarity score between 0 (no match) and 1 (exact match) to the best-matching option. If none of the options match well with the given {entity_type} '{mention}', choose the option 'None'. You are only allowed to give the answer based on the candidates provided to you and you should give your answer in the `normalised_tag` based on only and the values in full from `candidates` use it as a multiple choice answer and do not give me anything like 1. name or any other random stuff, just give me the normalized tag that you think is the best fit from the candidates list.

Task Description:
You are presented with a term, referred to as the '{entity_type} mention', extracted from an RNASeq experiment dataset sample. Accompanying this term is a list of normalized options, each derived from the {ontology} ontology and provided with contextual information including descriptions and synonyms.

Your specific task is to identify which of the listed normalized options corresponds most closely to the '{entity_type} mention'. This involves a careful comparison of the mention against each option's context. Upon determining the most suitable match, you are to provide two pieces of information:

1. Normalized Tag: Select the normalized term from the provided list of candidates that you deem to be the best match for the '{entity_type} mention'. Your response should be the exact term as it appears in the list, without any alterations or additional commentary. This term will be referred to as the 'normalized_tag'.

2. Reasoning and Similarity Score: Offer a clear rationale for your choice of the 'normalized_tag', and accompany this explanation with a similarity score. The score should be a decimal between 0 and 1, where 0 signifies no match and 1 signifies an exact match. The reasoning should elucidate the connection between the mention and the chosen normalized term, based on the context provided.

If, after thorough consideration, you conclude that none of the options sufficiently match the '{entity_type} mention', you are to select 'None' as the 'normalized_tag'. This decision should also be justified with reasoning and accompanied by an appropriate similarity score reflecting the lack of a suitable match.

Please adhere strictly to the instructions, ensuring that your 'normalized_tag' selection is confined to the exact terms listed under 'candidates'. Any deviation from the listed options or inclusion of extraneous information in the 'normalized_tag' will be considered non-compliant with the task requirements.

Remember, your responses must be concise, precise, and strictly based on the provided 'candidates'. The 'normalized_tag' should be an unmodified term from the list, and the reasoning should clearly justify its selection along with an appropriate similarity score.


{format_instructions}
"""


def _get_gpt_predictions(
    mention, entity_type, ontology, candidates, cached_dictionary, model_name
):
    """
    Generates predictions from a GPT model for a given mention and its possible entity types.

    This function formats a prompt with the mention, entity type, ontology, and candidate definitions
    using a template. It then sends the prompt to the specified GPT model and parses the output to
    obtain predictions.

    Args:
        mention (str): The mention text for which predictions are to be generated.
        entity_type (str): The type of entity to which the mention belongs.
        ontology (str): The ontology associated with the entity type.
        candidates (list): A list of candidate entities.
        cached_dictionary (dict): A dictionary containing cached information for entities.
        model_name (str): The name of the GPT model to be used for prediction.

    Returns:
        The parsed prediction output from the GPT model.

    The function utilizes a predefined prompt template and a parser for the model's output. It also
    uses a context retrieval function to get additional information from the cached dictionary. The
    output is expected to be in a format that can be parsed by the specified PydanticOutputParser.

    Example:
        >>> mention = "TP53"
        >>> entity_type = "gene"
        >>> ontology = "Human Phenotype Ontology"
        >>> candidates = ["Tumor protein p53", "Cellular tumor antigen p53"]
        >>> cached_dictionary = {"TP53": "Tumor protein p53"}
        >>> model_name = "gpt-3.5-turbo"
        >>> prediction = _get_gpt_predictions(mention, entity_type, ontology, candidates, cached_dictionary, model_name)
        >>> print(prediction)
        # The output will be the parsed prediction from the GPT model.
    """
    model = OpenAI(model_name=model_name, temperature=0.0)
    candidate_str, definition_str, i = get_context_from_dict(
        ontology, candidates, cached_dictionary
    )
    parser = PydanticOutputParser(pydantic_object=Choice)
    prompt = PromptTemplate(
        template=template_prompt,
        input_variables=[
            "mention",
            "entity_type",
            "ontology",
            "definition_str",
            "candidate_str",
            "i",
        ],
        partial_variables={"format_instructions": parser.get_format_instructions()},
    )
    _input = prompt.format_prompt(
        mention=mention,
        entity_type=entity_type,
        ontology=ontology,
        definition_str=definition_str,
        candidate_str=candidate_str,
        i=str(i + 1),
    )
    output = model.predict(_input.to_string())
    return parser.parse(output)
