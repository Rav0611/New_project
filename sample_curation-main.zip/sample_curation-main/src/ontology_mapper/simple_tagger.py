import re


class SimpleTagger:
    """
    A simple tagger class that uses a lexicon to find ontology matches within text.

    Attributes:
        lex (dict): A dictionary mapping synonyms (lowercased) to their ontology terms.
    """

    def __init__(self, lexicon):
        """
        Initializes the SimpleTagger with a given lexicon.

        Args:
            lexicon (dict): A dictionary mapping synonyms to ontology terms.
        """
        self.lex = {syn.lower(): onto for syn, onto in lexicon.items()}

    def _lookup(self, tokens, are_lower=False):
        """
        Looks up a phrase in the lexicon and returns the ontology term if found.

        Args:
            tokens (list of str): The phrase split into tokens.
            are_lower (bool): Flag indicating whether the tokens are already lowercased.

        Returns:
            The ontology term if the phrase is found in the lexicon, otherwise None.
        """
        phrase = " ".join(tokens)
        if not phrase:
            return
        if phrase in self.lex:
            return self.lex[phrase]
        if phrase[-1] == "s" and phrase[:-1] in self.lex:
            return self.lex[phrase[:-1]]
        if not are_lower:
            return self._lookup(list(map(str.lower, tokens)), True)

    def _longest_match(self, tokens, n_max, matched=None):
        """
        Finds the longest matches in the lexicon for a sequence of tokens.

        Args:
            tokens (list of str): The phrase split into tokens.
            n_max (int): The maximum number of tokens to consider for a match.
            matched (list of int): A list indicating which tokens have been matched.

        Returns:
            A list of ontology terms that are the longest matches for the tokens.
        """
        if n_max < 1:
            return []
        if matched is None:
            matched = [0] * len(tokens)
        tags = []
        for i in range(n_max, len(tokens) + 1):
            if 1 in matched[i - n_max : i]:
                continue
            if self._lookup(tokens[i - n_max : i]):
                matched[i - n_max : i] = [1] * n_max
                tags.append(self._lookup(tokens[i - n_max : i]))
        return tags + self._longest_match(tokens, n_max - 1, matched)

    def match_value(self, val):
        """
        Matches values from a string to ontology terms in the lexicon.

        Args:
            val (str): The string to match values from.

        Returns:
            A set of ontology terms that match parts of the input string.
        """
        phrases = map(
            lambda x: x.strip("+- "),
            (filter(lambda x: x != "", re.split("[^a-zA-Z0-9 +-]", val))),
        )

        ontos = set()
        for phrase in phrases:
            ontos = ontos.union(self._longest_match(phrase.split(" "), 5))
        return ontos
