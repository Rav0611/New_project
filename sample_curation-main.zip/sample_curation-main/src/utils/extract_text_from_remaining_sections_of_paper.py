import random
import re


def extract_remaining_text_sections(text):
    """
    Extracts and combines specific sections from a given text.

    This function processes a block of text to extract the first 750 words, a random selection of
    sentences from the middle, and the last 400 words. The extracted sections are then combined
    into a single text block, with the first and last parts separated from the random middle
    sentences by newlines.

    Args:
        text (str): The text from which to extract the sections.

    Returns:
        str: A string that combines the first 750 words, a random selection of sentences from the
            remaining text, and the last 400 words.

    The function uses nested helper functions to split the text into sentences, select the first
    and last N words, and randomly sample sentences from the remaining text. It is designed to
    provide a summary view of a longer document by including the beginning, a sample from the
    middle, and the end.

    Example:
        >>> text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit... (long text)"
        >>> extracted_text = extract_remaining_text_sections(text)
        >>> print(extracted_text)
        # Output will be a string with the first 750 words, 8 random sentences from the middle,
        # and the last 400 words of the input text.
    """

    def split_into_sentences(text):
        sentences = re.split(r"(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s", text)
        return sentences

    def get_first_n_words(sentences, limit):
        word_count = 0
        selected_text = ""
        for sentence in sentences:
            words_in_sentence = len(sentence.split())
            if word_count + words_in_sentence <= limit:
                selected_text += sentence + " "
                word_count += words_in_sentence
            else:
                break
        return selected_text.strip()

    def get_last_n_words(sentences, limit):
        word_count = 0
        selected_text = ""
        for sentence in reversed(sentences):
            words_in_sentence = len(sentence.split())
            if word_count + words_in_sentence <= limit:
                selected_text = sentence + " " + selected_text
                word_count += words_in_sentence
            else:
                break
        return selected_text.strip()

    sentences = split_into_sentences(text)
    first_part = get_first_n_words(sentences, 750)
    last_part = get_last_n_words(sentences, 400)
    remaining_sentences = [
        s for s in sentences if s not in first_part and s not in last_part
    ]
    random_sentences = random.sample(
        remaining_sentences, min(len(remaining_sentences), 8)
    )
    combined_text = (
        first_part + "\n\n" + " ".join(random_sentences) + "\n\n" + last_part
    )
    return combined_text
