import time
import xml.etree.ElementTree as ET

import requests


def fetch_pmc_ids(pubmed_ids, batch_size=200, retries=3, delay=0.5):
    """
    Retrieves the corresponding PMC (PubMed Central) IDs for a list of PubMed IDs.

    This function queries the NCBI E-utilities API to convert PubMed IDs to PMC IDs. It processes
    the IDs in batches and includes retry logic for handling request failures. If the conversion
    is successful, the PMC ID is stored in a dictionary with the PubMed ID as the key. If a PubMed
    ID does not have a corresponding PMC ID or if the request fails after all retries, the value
    is set to None.

    Args:
        pubmed_ids (list of str): A list of PubMed IDs to be converted to PMC IDs.
        batch_size (int, optional): The number of PubMed IDs to process in each batch. Defaults to 200.
        retries (int, optional): The number of times to retry a failed request before giving up. Defaults to 3.
        delay (float, optional): The delay in seconds between each retry attempt. Defaults to 0.5.

    Returns:
        dict: A dictionary mapping PubMed IDs to their corresponding PMC IDs, or None if not found.

    The function uses the 'elink' E-utility which provides an XML response. The response is parsed
    using the ElementTree XML API to extract the PMC IDs. The function includes error handling for
    HTTP errors and request exceptions.

    Example:
        >>> pubmed_ids = ['12345678', '87654321']
        >>> pmc_ids = fetch_pmc_ids(pubmed_ids)
        >>> print(pmc_ids)
        {'12345678': 'PMC123456', '87654321': None}  # Example output
    """
    pmc_ids = {}
    base_url = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/elink.fcgi"
    session = requests.Session()

    batches = [
        pubmed_ids[i : i + batch_size] for i in range(0, len(pubmed_ids), batch_size)
    ]

    for batch in batches:
        attempt = 0
        while attempt < retries:
            params = {
                "dbfrom": "pubmed",
                "id": ",".join(map(str, batch)),
                "db": "pmc",
                "retmode": "xml",
                "tool": "pubmed_converter",
                "email": "rajdeep.mondal@elucidata.io",
            }
            try:
                response = session.get(base_url, params=params)
                if response.status_code == 200:
                    root = ET.fromstring(response.content)
                    for linkset in root.findall(".//LinkSet"):
                        pmid = linkset.find("./IdList/Id").text
                        pmc_id = None
                        linksetdb = linkset.find(
                            ".//LinkSetDb[LinkName='pubmed_pmc_refs']"
                        )
                        if linksetdb is not None:
                            link = linksetdb.find(".//Link/Id")
                            if link is not None:
                                pmc_id = link.text
                        pmc_ids[pmid] = pmc_id
                    break
                else:
                    print(f"Error fetching PMC IDs: {response.status_code}")
                    attempt += 1
                    time.sleep(delay)
            except requests.RequestException as e:
                print(f"Request failed: {e}")
                attempt += 1
                time.sleep(delay)
        if attempt == retries:
            for pmid in batch:
                pmc_ids[pmid] = None
    return pmc_ids
