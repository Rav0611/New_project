import inspect
import os
import re
import sys

sys.path.append("/app/src/utils/")

import logging
from io import StringIO
from os import environ

from botocore.exceptions import ClientError
from cloudpathlib import CloudPath
from numpy.core import ufunc

import utils.workspace.application_error_info as app_err_info
import utils.workspace.constants as const
import utils.workspace.http_response_codes as http_res_codes
from utils.workspace.auth import Polly

CACHE = {}


def isclass(object):
    """Return true if the object is a class.

    Class objects provide these attributes:
        __doc__         documentation string
        __module__      name of module in which this class was defined"""
    return isinstance(object, type)


def checkclass(cls) -> None:
    # checking class or not
    # it is in allowed classes or not
    if not isclass(cls):
        print("Note : use class to get help")
        raise TypeError(title="Use class")

    if cls.__name__ not in ["Polly", "OmixAtlas", "Cohort", "Workspaces"]:
        print("Other class methods not allowed")
        raise Exception(title="Other class are not allowed")


class BaseExceptionError(Exception):
    """
    Base Exception class for v2 APIs.
    All custom exceptions are created by extending this class.
    Exception has 4 attributes corresponding to details sent in 'error' object
    in response JSON -
        status - http status code
        code - application specific error code
        title - title of error
        detail - details of error
    """

    def __init__(self, status, code, title, detail):
        Exception.__init__(self)
        self.title = title
        self.detail = detail

    def as_dict(self):
        return {"title": self.title, "detail": self.detail}

    def as_str(self):
        exception_str = "Exception Type : " + self.__class__.__name__
        exception_str += "\nTitle - " + self.title if self.title else ""
        exception_str += "\nDetails - " + self.detail if self.detail else ""
        return exception_str

    def __str__(self):
        return f"{self.__class__.__name__} ({self.title}): {self.detail}"


def get_fun_name(function_name: str) -> str:
    # getting function name for input function name
    # get_all_omixatlas() -> get_all_omixatlas
    if function_name and function_name.find("(") != -1:
        return function_name.split("(")[0]
    elif function_name:
        return function_name
    return None


class InvalidParameterException(Exception):
    def __init__(self, parameter):
        self.parameter = parameter

    def __str__(self):
        return f"Empty or Invalid Parameters = {self.parameter}."


def get_module(module: str) -> object:
    # importing module
    try:
        __import__(module)
    except ImportError:
        return {}

    return sys.modules[module]


def get_all(item: object) -> object:
    # getting all next items (like function,class) for a module
    try:
        _all = item.__all__
    except AttributeError:
        _all = None
    return _all


def path_to_import(this_py: str, mod_path: str, init_py: str) -> str:
    # will return path to import next modules
    if os.path.isfile(this_py) and mod_path.endswith(".py"):
        return mod_path[:-3]
    elif os.path.isfile(init_py):
        return mod_path
    else:
        return None


def _import(name: str, to_import: str) -> bool:
    # this function will import a given module
    try:
        old_stdout = sys.stdout
        old_stderr = sys.stderr
        try:
            sys.stdout = StringIO()
            sys.stderr = StringIO()
            __import__("%s.%s" % (name, to_import))
        finally:
            sys.stdout = old_stdout
            sys.stderr = old_stderr
            return True
    except (Exception, SystemExit):
        return False


def _getmembers(item: object) -> object:
    # returning class member functions
    import inspect

    try:
        members = inspect.getmembers(item)
    except Exception:
        members = [(x, getattr(item, x)) for x in dir(item) if hasattr(item, x)]
    return members


def get_member(name: str, n: str, v: object) -> str:
    # return member name and module name
    try:
        item_name = getattr(v, "__name__", "%s.%s" % (name, n))
        mod_name = getattr(v, "__module__", None)
    except NameError:
        item_name = "%s.%s" % (name, n)
        mod_name = None
    return item_name, mod_name


def is_exe(
    item_name: str, mod_name: str, name: str, n: str, v: object, _all: str
) -> bool:
    # function will return next class or function or modules will push
    # in stack or not
    if "." not in item_name and mod_name:
        item_name = "%s.%s" % (mod_name, item_name)

    if not item_name.startswith(name + "."):
        if isinstance(v, ufunc):
            return False
        else:
            return True
    elif not (inspect.ismodule(v) or _all is None or n in _all):
        return True


def push_next_members(
    import_modules: bool, item: object, name: str, _all: object, stack
) -> None:
    # pushing next members of given modules
    if import_modules and hasattr(item, "__path__"):
        for pth in item.__path__:
            for mod_path in os.listdir(pth):
                this_py = os.path.join(pth, mod_path)
                init_py = os.path.join(pth, mod_path, "__init__.py")
                to_import = path_to_import(this_py, mod_path, init_py)
                if not to_import or to_import == "__init__":
                    continue
                if not _import(name, to_import):
                    continue

    for n, v in _getmembers(item):
        item_name, mod_name = get_member(name, n, v)
        if is_exe(item_name, mod_name, name, n, v, _all):
            continue
        stack.append(("%s.%s" % (name, n), v))


def get_docs(name: str, kind: str, index: int, item: object) -> None:
    # storing docstring for a function or class in CACHE variable
    try:
        doc = inspect.getdoc(item)
    except NameError as e:
        raise NameError(title="Name Error", detail=e)

    if doc is not None:
        CACHE[name] = (doc, kind, index)


def _lookfor_generate_cache(module: str, import_modules: bool) -> dict:
    # function will return all the classes and function information
    # like name, docstring, kind for a module
    module = get_module(module)
    seen = {}
    index = 0
    stack = [(module.__name__, module)]

    while stack:
        name, item = stack.pop(0)
        if id(item) in seen:
            continue
        seen[id(item)] = True

        index += 1
        kind = "object"

        if inspect.ismodule(item):
            kind = "module"
            _all = get_all(item)
            push_next_members(import_modules, item, name, _all, stack)
        elif inspect.isclass(item):
            kind = "class"
            for n, v in _getmembers(item):
                stack.append(("%s.%s" % (name, n), v))
        elif hasattr(item, "__call__"):
            kind = "func"
        get_docs(name, kind, index, item)
    return CACHE


def lookfor(module: str = None, import_modules: bool = True) -> list:
    # function will return names, docstrings  of classes and functions for a module
    CACHE = _lookfor_generate_cache(module, import_modules)

    found = []

    for name, (docstring, kind, index) in CACHE.items():
        if kind in ("module", "object"):
            continue
        doc = docstring.lower()
        found.append((name, kind, doc))

    return found


def get_line(fun: str, kind: str, txt: str, function_name: str, cls, doc: bool) -> str:
    # function will return lines to print
    # for a function or class
    Link = {
        "cohort": "https://github.com/ElucidataInc/PublicAssets/blob/master/polly-python/example/cohort.ipynb",
        "omixatlas": "https://github.com/ElucidataInc/PublicAssets/blob/master/polly-python/example/omixatlas.ipynb",
        "polly": "https://github.com/ElucidataInc/PublicAssets/blob/master/polly-python/example/polly.ipynb",
        "workspaces": "https://github.com/ElucidataInc/PublicAssets/blob/master/polly-python/example/workspaces.ipynb",
        "add_datasets": "https://github.com/elucidatainc/polly-python/blob/main/ingest/data_ingestion_caseid_1.ipynb",
    }
    line = None
    class_name = cls.__name__.lower()
    description = ""
    lines = txt.split("\n")
    # breaking the text into lines
    for line in lines:
        if not line:
            description = description[:-1]
            break
        description += line + "\n"

    if doc:
        if kind == "class" and not function_name:
            line = (
                "Name - %s()\nDocumentation - %s\n%s class contain following methods\n\n"
                % (fun.split(".")[-1], txt, cls.__name__)
            )
        elif kind == "func" and function_name:
            line = "Name - %s()\nDocumentation - %s \n\n" % (fun.split(".")[-1], txt)
        else:
            line = "Name - %s() \nDescription - %s\n" % (
                fun.split(".")[-1],
                description,
            )
    else:
        if kind == "class" and not function_name:
            line = "Name - %s() \n   Description - %s\n   Link - %s\n" % (
                fun.split(".")[-1],
                description,
                Link[class_name],
            )

        elif kind == "func" and function_name:
            line = "Name - %s() \n   Description - %s\n   Link - %s\n" % (
                fun.split(".")[-1],
                description,
                Link[function_name],
            )

    return line


def checkpath(fun: str) -> bool:
    # checking path for a class or function
    # if it includes '_' ,means it is a private function
    # other wise not we should show it
    should_show_fun = True
    for name in fun.split("."):
        if name.startswith("_"):
            should_show_fun = False
            break
    return should_show_fun


def get_txt(
    cls,
    fun: str,
    kind: str,
    doc: str,
    function_name: str,
    should_show_fun: bool,
    is_doc: bool,
) -> str:
    # converting function, class docstrings rst to txt
    # returning text to print
    if (
        cls.__name__ in fun.split(".")
        and (not function_name or function_name == fun.split(".")[-1])
        and should_show_fun
    ):
        import rst2txt
        from docutils.core import publish_string

        # converting rst to txt
        txt = publish_string(
            source=doc,
            writer=rst2txt.Writer(),
            settings_overrides={"report_level": 6},
        ).decode("utf-8")

        if txt and "meta private" not in txt:
            while txt.find(">>:ref:`") != -1:
                # removing rst syntax that remains after rst to txt conversion
                # removing link syntax
                x = txt.find(">>:ref:`")
                y = txt.find("`<<") + 3
                str_to_del = txt[x:y]
                str_to_ins = str_to_del.split(">>:ref:`")[1]
                str_to_ins = "visit " + str_to_ins.split(" ")[0]
                txt = txt.replace(str_to_del, str_to_ins)
            line = get_line(fun, kind, txt, function_name, cls, is_doc)
            return line
    return None


def example(cls, function_name: str = "") -> None:
    """
    function to see examples for class - Polly, OmixAtlas, Workspaces, Cohort and it's member funtions

    ``Args:``
        ``function_name (optional) str:`` provide function name to see examples default empty.

    ``Returns:``
        if you provide function_name to search then it will give example link for that function other wise it \
will give link for all examples for that class.
    """
    checkclass(cls)
    function_name = get_fun_name(function_name)
    help_text = []
    # pushing those function and classes whose examples has been asked
    for fun, kind, doc in lookfor("polly", True):
        should_show_fun = checkpath(fun)
        txt = get_txt(cls, fun, kind, doc, function_name, should_show_fun, False)
        if txt:
            help_text.append(txt)

    if help_text == []:
        help_text.append("nothing found")

    print("\n".join(help_text))


class InvalidPathException(Exception):
    def __str__(self):
        return "This path does not represent a file or a directory. Please try again."


class OperationFailedException(Exception):
    def __init__(self, reason):
        self.reason = reason

    def __str__(self):
        return f"{self.reason}"


def has_error_message(response):
    try:
        for key in response.json().keys():
            if key in {"error", "errors"}:
                return True
        return False
    except Exception:
        return False


def extract_json_api_error(response):
    error = response.json().get("error")
    if error is None:
        error = response.json().get("errors")[0]
    if "title" in error:
        title = error.get("title")
    if "detail" in error:
        detail = error.get("detail")
    return title, detail


class UnauthorizedException(Exception):
    def __str__(self):
        return "Expired or Invalid Token"


class RequestException(Exception):
    def __init__(self, title, detail=None):
        self.title = title
        self.detail = detail


def error_handler(response):
    if has_error_message(response):
        title, detail = extract_json_api_error(response)
        if title == app_err_info.REPOSITORY_LOCKED:
            detail = app_err_info.REPOSITORY_LOCKED_DETAIL
        raise RequestException(title, detail)
    elif response.status_code == 401:
        raise UnauthorizedException

    response.raise_for_status()


def get_user_details(session, base_url):
    """
    Function to get user details
    """
    me_url = f"{base_url}/users/me"
    details = session.get(me_url)
    error_handler(details)
    user_details = details.json().get("data", {}).get("attributes")
    user_details["user_id"] = int(details.json().get("data", {}).get("id"))
    return user_details


class BadRequestError(BaseExceptionError):
    status = http_res_codes.BAD_REQUEST
    code = app_err_info.BAD_REQUEST_CODE
    title = app_err_info.BAD_REQUEST_TITLE
    detail = app_err_info.BAD_REQUEST_DETAIL

    def __init__(self, code=None, status=None, title=None, detail=None):
        if code:
            self.code = code
        if status:
            self.status = status
        if title:
            self.title = title
        if detail:
            self.detail = detail


class AccessDeniedError(BaseExceptionError):
    status = http_res_codes.FORBIDDEN
    code = app_err_info.FORBIDDEN_CODE
    title = app_err_info.FORBIDDEN_TITLE
    detail = app_err_info.FORBIDDEN_DETAIL

    def __init__(self, title=None, detail=None):
        if title:
            self.title = title
        if detail:
            self.detail = detail


def workspaces_permission_check(self, workspace_id) -> bool:
    """
    Function to check access of a user for a given workspace id.
    """
    permission_url = f"{self.base_url}/workspaces/{workspace_id}/permissions"
    response = self.session.get(permission_url, params={"include": "user"})
    error_handler(response)
    user_details = get_user_details(self.session, self.base_url_auth)
    user_id = user_details.get("user_id")
    if "data" in response.json():
        json_data = response.json().get("data")
    else:
        raise BadRequestError(detail="Incorrect response format")
    for user in json_data:
        if "attributes" in user:
            attributes = user.get("attributes")

        else:
            raise BadRequestError(detail="Incorrect response format")
        if user_id == attributes["user_id"] and attributes["project_id"] == int(
            workspace_id
        ):
            if attributes["permission"] != "read":
                return True
            else:
                raise AccessDeniedError(
                    detail=f"Read-only permission over the "
                    f"workspace-id {workspace_id}"
                )
    return False


def upload_to_S3(cloud_path: str, local_path: str, credentials: dict) -> None:
    """
    Uploads a local file or folder to the specified cloud path on AWS S3.

    This method sets the necessary AWS credentials in the environment, initializes a CloudPath
    object for the given cloud path, and uploads the file or folder from the local path to S3.
    If the cloud path does not exist, it creates the necessary directories.

    Args:
        cloud_path (str): The S3 cloud path where the file or folder will be uploaded.
        local_path (str): The local path to the file or folder to be uploaded.
        credentials (dict): A dictionary containing AWS credentials with keys 'AccessKeyId',
                            'SecretAccessKey', and 'SessionToken'.

    Raises:
        OperationFailedException: If the upload process encounters an error.

    The method uses the CloudPath library to handle the upload process, which abstracts away
    the details of interacting with S3. It ensures that the environment variables for AWS
    credentials are set before attempting the upload.
    """
    os.environ["AWS_ACCESS_KEY_ID"] = credentials["AccessKeyId"]
    os.environ["AWS_SECRET_ACCESS_KEY"] = credentials["SecretAccessKey"]
    os.environ["AWS_SESSION_TOKEN"] = credentials["SessionToken"]

    source_path = CloudPath(cloud_path)

    if not source_path.exists():
        source_path.mkdir(parents=True)

    try:
        source_path.upload_from(local_path, force_overwrite_to_cloud=True)
    except ClientError as e:
        raise OperationFailedException(e)


def get_platform_value_from_env(
    variable: str, default_val: str, passed_val: str
) -> str:
    """
    Retrieves the value of an environment variable, with the option to override.

    This method attempts to retrieve the value of an environment variable specified by `variable`.
    If a value is passed explicitly, it overrides any environment variable. If the environment
    variable is not set, it falls back to a default value. When retrieving the environment variable,
    it extracts a substring based on a pattern match within the variable's value.

    Args:
        variable (str): The name of the environment variable to retrieve.
        default_val (str): The default value to use if the environment variable is not set.
        passed_val (str): An explicitly passed value that overrides the environment variable.

    Returns:
        str: The value of the environment variable, the explicitly passed value, or the default value.
    """
    if passed_val:
        default_val = passed_val
    elif environ.get(variable, None) is not None:
        POLLY_TYPE = os.getenv(variable)
        env_val = re.search("https://(.+?).elucidata.io", POLLY_TYPE)
        default_val = env_val.group(1)
    return default_val


class MissingKeyException(Exception):
    def __init__(self, key):
        self.key = key

    def __str__(self):
        return f"Missing keys {self.key}"


def get_sts_creds(sts_dict: dict) -> dict:
    """
    Extracts and returns the AWS Security Token Service (STS) credentials from a given dictionary.

    This method parses a dictionary containing STS credentials provided by Polly's API and
    extracts the temporary credentials needed for AWS operations.

    Args:
        sts_dict (dict): A dictionary containing the STS credentials response from Polly's API.

    Returns:
        dict: A dictionary containing the 'AccessKeyId', 'SecretAccessKey', and 'SessionToken'
                required for AWS operations.

    Raises:
        MissingKeyException: If the expected keys are not present in the sts_dict.
        InvalidParameterException: If the sts_dict is not a dictionary or is None.
    """
    if sts_dict and isinstance(sts_dict, dict):
        if "data" in sts_dict:
            data = sts_dict.get("data")
            if "attributes" in data[0]:
                attributes = data[0].get("attributes")
                if "credentials" in attributes:
                    return attributes.get("credentials")
                else:
                    raise MissingKeyException("credentials")
            else:
                raise MissingKeyException("attributes")
        else:
            raise MissingKeyException("data")
    else:
        raise InvalidParameterException("sts_dict")


def make_path(prefix: any, postfix: any) -> str:
    """
    Constructs a normalized filesystem path by combining two path components.

    This method takes a prefix and postfix as path components, joins them to form a full path,
    and normalizes the resulting path. It ensures that the path follows the conventions of the
    operating system's filesystem.

    Args:
        prefix (str): The initial part of the path.
        postfix (str): The final part of the path to be appended to the prefix.

    Returns:
        str: A normalized, well-formed filesystem path.

    Raises:
        InvalidParameterException: If either the prefix or postfix is not provided.
    """
    if not prefix:
        raise InvalidParameterException("prefix")
    if not postfix:
        raise InvalidParameterException("postfix")
    return os.path.normpath(f"{prefix}/{postfix}")


class Workspaces:
    """
    A class to interact with Polly workspaces for various operations such as creating a workspace,
    fetching a list of workspaces, uploading data to a workspace, and downloading data from a workspace.

    To utilize the functionality provided by this class, an instance must be initialized with the
    necessary authentication token obtained from Polly. This class provides methods to perform
    operations on Polly workspaces using the Polly API.

    Usage:
        >>> from polly.workspaces import Workspaces
        >>> workspaces = Workspaces(token="your_polly_token")

    The class provides private helper methods such as `_s3_util` to assist with S3 operations,
    and public methods like `upload_to_workspaces` to upload files or directories to a specified
    workspace on Polly.

    Example:
        To create a Workspaces object for the production environment with a given token:
        >>> workspaces = Workspaces(token="your_polly_token")

        To create a Workspaces object for a custom environment:
        >>> workspaces = Workspaces(token="your_polly_token", env="custom_env")
    """

    example = classmethod(example)

    def __init__(self, token=None, env="", default_env="polly") -> None:
        """
        Initializes a Workspaces object to interact with Polly workspaces.

        This constructor sets up the Workspaces object with the necessary details to authenticate
        and interact with Polly's API endpoints. It determines the environment to use based on
        the provided parameters and environment variables, sets up the base URLs for API requests,
        and initializes a Polly session for authentication.

        Args:
            token (str, optional): The authentication token for Polly. Defaults to None.
            env (str, optional): The environment name to override the default or environment variable. Defaults to "".
            default_env (str, optional): The default environment to use if no other is specified or found. Defaults to "polly".

        The constructor checks for the presence of a compute environment variable (`COMPUTE_ENV_VARIABLE`)
        and gives it priority over the `env` parameter if present. It then configures the base URLs for
        Polly's API and authentication endpoints based on the determined environment. It also sets an
        environment string that is used in constructing S3 paths for AWS interactions.

        The `env_string` is set to "prod" if the environment is "polly", "test" if the environment is
        "testpolly", and "devenv" for any other environment.

        Example:
            To create a Workspaces object for the production environment with a given token:
            workspaces = Workspaces(token="your_polly_token")

            To create a Workspaces object for a custom environment:
            workspaces = Workspaces(token="your_polly_token", env="custom_env")
        """
        env = get_platform_value_from_env(const.COMPUTE_ENV_VARIABLE, default_env, env)
        self.session = Polly.get_session(token, env=env)
        self.base_url = f"https://v2.api.{self.session.env}.elucidata.io"
        self.base_url_auth = f"https://apis.{self.session.env}.elucidata.io/auth"
        self.resource_url = f"{self.base_url}/workspaces"
        if self.session.env == "polly":
            self.env_string = "prod"
        elif self.session.env == "testpolly":
            self.env_string = "test"
        else:
            self.env_string = "devenv"

    def _s3_util(self, workspace_id, workspace_path):
        """
        Retrieves S3 client credentials and constructs the S3 path for a given workspace.

        This private method is part of the Workspaces class and is used internally to obtain
        the necessary credentials to interact with AWS S3. It constructs the S3 path where
        files and folders will be uploaded within the specified workspace.

        Args:
            workspace_id (int): The ID of the workspace for which the S3 path and credentials
                                are being retrieved.
            workspace_path (str): The path within the workspace where files and folders will
                                be uploaded.

        Returns:
            tuple: A tuple containing the S3 path (str) and credentials (dict).

        The method makes an HTTP GET request to the Polly API to retrieve temporary security
        credentials for the AWS S3 client. It then constructs the S3 path using the workspace
        ID and the provided workspace path. The S3 path is returned along with the credentials
        in a tuple.

        Raises:
            Exception: If there is an error in obtaining the credentials or constructing the S3 path.

        This method is typically called by other methods within the Workspaces class that require
        access to S3 for uploading or downloading files.

        Example:
            Assuming the method is part of an instantiated object `workspaces` with appropriate
            base_url and session attributes, it can be called as follows:
            s3_path, credentials = workspaces._s3_util(12345, "my_workspace/data/")
        """
        sts_url = f"{self.base_url}/projects/{workspace_id}/credentials/files"
        creds = self.session.get(sts_url)
        error_handler(creds)
        credentials = get_sts_creds(creds.json())
        bucket = f"mithoo-{self.env_string}-project-data-v1"
        s3_path = f"{bucket}/{workspace_id}/"
        s3_path = f"s3://{make_path(s3_path, workspace_path)}"
        return s3_path, credentials

    def upload_to_workspaces(
        self, workspace_id: int, workspace_path: str, local_path: str
    ) -> None:
        """
        Uploads a file or folder to a specified workspace on Polly.

        This method uploads a local file or directory to a specified path within a Polly workspace.
        The workspace path must start with "polly://", and the method will create the folder at the
        workspace path if it does not already exist. The method performs several checks to ensure
        that the parameters are valid, the local file or directory exists, and the user has the
        necessary permissions to upload to the specified workspace.

        Args:
            workspace_id (int): The ID of the workspace where the file or folder will be uploaded.
            workspace_path (str): The path within the workspace where the file or folder will be
                                    uploaded. Must be prefixed with "polly://".
            local_path (str): The local path to the file or folder to be uploaded.

        Raises:
            InvalidParameterException: If any of the parameters are invalid or not provided.
            InvalidPathException: If the local file or folder does not exist.
            AccessDeniedError: If the user does not have permission to upload to the specified
                                workspace.

        The method uses the `_s3_util` method to obtain the S3 path and credentials for the upload
        and then calls the `upload_to_S3` function to perform the actual upload. Upon successful
        upload, an informational message is logged.

        Example:
            To upload a file to a workspace, you would call this method as follows:
            workspaces.upload_to_workspaces(
                workspace_id=12345,
                workspace_path="polly://my_workspace/data/",
                local_path="/path/to/my_file.txt"
            )
        """
        if not (workspace_id and isinstance(workspace_id, int)):
            raise InvalidParameterException("workspace_id")
        if not (local_path and isinstance(local_path, str)):
            raise InvalidParameterException("local_path")
        if not (workspace_path and isinstance(workspace_path, str)):
            raise InvalidParameterException("workspace_path")
        isExists = os.path.exists(local_path)
        if not isExists:
            raise InvalidPathException
        access_workspace = workspaces_permission_check(self, workspace_id)
        if not access_workspace:
            raise AccessDeniedError(
                detail=f"Access denied to workspace-id - {workspace_id}"
            )
        if workspace_path.startswith("polly://"):
            workspace_path = workspace_path.split("polly://")[1]
        s3_path, credentials = self._s3_util(workspace_id, workspace_path)
        upload_to_S3(s3_path, local_path, credentials)
        logging.basicConfig(level=logging.INFO)
        logging.info(f"Upload successful on workspace-id={workspace_id}.")
