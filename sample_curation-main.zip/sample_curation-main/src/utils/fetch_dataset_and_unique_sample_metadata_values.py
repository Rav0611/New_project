import copy

import GEOparse
import pandas as pd

from utils.cleanup_metadata import clean_metadata


def extract_unique_metadata_values(dataframe):
    """
    Extracts unique values from each column of a DataFrame and returns them as a dictionary.

    This function creates a deep copy of the input DataFrame to avoid modifying the original data.
    It then iterates over each column, drops any NaN values, and collects the unique values into a list.
    These lists are stored in a dictionary with the column names as keys.

    Args:
        dataframe (pd.DataFrame): The DataFrame from which to extract unique metadata values.

    Returns:
        dict: A dictionary where each key is a column name from the DataFrame and each value is a list
                of unique values found in that column.

    The function is useful for getting a sense of the variety of data within each column of a DataFrame,
    particularly in the context of metadata where each column may represent a different type of information
    about samples in a dataset.

    Example:
        >>> import pandas as pd
        >>> df = pd.DataFrame({
                'A': ['foo', 'bar', 'foo', 'baz'],
                'B': ['one', 'one', 'two', 'three'],
                'C': [1, 2, 2, 3]
            })
        >>> unique_values = extract_unique_metadata_values(df)
        >>> print(unique_values)
        {'A': ['foo', 'bar', 'baz'], 'B': ['one', 'two', 'three'], 'C': [1, 2, 3]}
    """

    dataframe_copy = copy.deepcopy(dataframe)
    return {
        column: dataframe_copy[column].dropna().unique().tolist()
        for column in dataframe_copy.columns
    }


def fetch_dataset_and_unique_sample_metadata_values(gse_id):
    """
    Fetches the dataset and unique sample metadata values for a given GEO Series ID (GSE ID).

    This function retrieves the metadata for all samples within a GEO Series using the GEOparse library.
    It flattens the metadata structure into a pandas DataFrame, sets the sample IDs as the index, and
    cleans up the metadata by removing unnecessary columns. It then extracts unique metadata values for
    each column in the DataFrame.

    Args:
        gse_id (str): The GEO Series ID for which the metadata is to be fetched.

    Returns:
        tuple: A tuple containing two elements:
            - pd.DataFrame: A DataFrame with the raw sample-level metadata.
            - dict: A dictionary with unique metadata values for each column in the DataFrame.

    Raises:
        Exception: If there is an error fetching the GEO Series data from NCBI.

    The function processes the metadata to remove columns that are not needed for further analysis,
    such as submission dates, platform IDs, and contact information. It also handles any exceptions
    that occur during the fetching process and prints an error message.

    Example:
        >>> gse_id = "GSE12345"
        >>> raw_metadata, unique_metadata = fetch_dataset_and_unique_sample_metadata_values(gse_id)
        >>> print(raw_metadata.head())
        >>> print(unique_metadata)
        # Output will be the raw metadata DataFrame and the dictionary of unique metadata values.
    """

    try:
        gse = GEOparse.get_GEO(geo=gse_id)
    except Exception as e:
        print(f"Error fetching GSE data: {e}")
        return None
    print(gse)
    flattened_data = []

    for gsm_key, gsm_value in gse.gsms.items():
        flattened_entry = {
            key: value[0] if isinstance(value, list) else value
            for key, value in gsm_value.metadata.items()
        }
        flattened_entry["GSM_ID"] = gsm_key
        flattened_data.append(flattened_entry)

    raw_sample_level_metadata = pd.DataFrame(flattened_data)
    raw_sample_level_metadata.set_index("GSM_ID", inplace=True)
    columns_to_drop = [
        "geo_accession",
        "submission_date",
        "last_update_date",
        "data_row_count",
        "platform_id",
        "status",
        "taxid_ch1",
        "channel_count",
        "series_id",
        "supplementary_file_1",
        "supplementary_file_2",
    ]
    columns_to_drop += [
        col for col in raw_sample_level_metadata.columns if "contact" in col
    ]
    raw_sample_level_metadata.drop(
        columns=columns_to_drop, inplace=True, errors="ignore"
    )
    return raw_sample_level_metadata, extract_unique_metadata_values(
        clean_metadata(copy.deepcopy(raw_sample_level_metadata))
    )
