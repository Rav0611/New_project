import logging
import time

import requests
from bs4 import BeautifulSoup

BASE_URL = "https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc="

REMOVE_WORDS = [
    "Title",
    "Sample type",
    "RNA",
    "Source name",
    "Organism",
    "Extracted molecule",
    "Description",
]


def send_request(url, max_retries=3, delay=0.5):
    """
    Sends an HTTP GET request to a specified URL with retry logic.

    This function attempts to send an HTTP GET request to the provided URL. If the request encounters
    an exception, the function will retry the request up to a specified number of times with a delay
    between each attempt. If all attempts fail, it logs the error and returns None.

    Args:
        url (str): The URL to which the HTTP GET request is to be sent.
        max_retries (int, optional): The maximum number of times to retry the request in case of failure.
                                        Defaults to 3.
        delay (float, optional): The delay in seconds to wait between each retry attempt. Defaults to 0.5.

    Returns:
        requests.Response or None: The response object from the requests library if the request is
                                        successful; otherwise, None.

    The function uses a requests session to send the request, which provides connection pooling and
    persistent headers. If the response status code indicates an error (4xx or 5xx), the function will
    raise an HTTPError, which is caught and handled by the retry logic.

    Example:
        >>> url = "https://api.example.com/data"
        >>> response = send_request(url)
        >>> if response:
        >>>     print(response.json())  # Process the successful response
        >>> else:
        >>>     print("Request failed after retries.")
    """
    with requests.Session() as session:
        for attempt in range(max_retries):
            try:
                response = session.get(url)
                response.raise_for_status()
                return response
            except requests.exceptions.RequestException as err:
                if attempt < max_retries - 1:
                    time.sleep(delay)
                    continue
                else:
                    logging.error(f"Error occurred: {err}")
                    return None


def fetch_geo_info_from_ncbi(gse_id, gsm_ids=None, max_retries=3, delay=0.5):
    """
    Retrieves GEO information from NCBI for a given GSE ID and optional GSM IDs.

    This function fetches the GEO Series (GSE) information from the NCBI website. If GSM IDs are provided,
    it also fetches the GEO Sample (GSM) information for each GSM ID. The function extracts the text
    between the 'Title' and 'Submission date' sections for both GSE and GSM entries.

    Args:
        gse_id (str): The GEO Series ID for which the information is to be fetched.
        gsm_ids (list of str, optional): A list of GEO Sample IDs for which the information is to be fetched.
                                            Defaults to None.
        max_retries (int, optional): The maximum number of retries for the HTTP request in case of failure.
                                        Defaults to 3.
        delay (float, optional): The delay in seconds between retries. Defaults to 0.5.

    Returns:
        str or None: A string containing the extracted information from the GEO webpage(s). If the required
                        text is not found or an HTTP request fails, it returns None.

    The function uses a helper function `send_request` to handle the HTTP requests and retries. It uses
    BeautifulSoup to parse the HTML content. If the 'Title' or 'Submission date' sections are not found,
    it logs an error message indicating the issue. The function also ensures that a delay is respected
    between requests when fetching multiple GSM entries to avoid overwhelming the server.

    Example:
        >>> gse_id = "GSE12345"
        >>> gsm_ids = ["GSM67890", "GSM67891"]
        >>> geo_info = fetch_geo_info_from_ncbi(gse_id, gsm_ids)
        >>> print(geo_info)
        "GSE12345: Title: Study of Drug X on Cancer Cells Submission date: 01-Jan-2020
            GSM67890: Title: Effects of Drug X on Cancer Cell Line A Submission date: 02-Jan-2020
            GSM67891: Title: Effects of Drug X on Cancer Cell Line B Submission date: 03-Jan-2020"
    """
    geo_url = f"{BASE_URL}{gse_id}"

    response = send_request(geo_url, max_retries, delay)
    if response is None:
        return None

    soup = BeautifulSoup(response.content, "html.parser")
    text_blob = ""

    if gsm_ids is not None:
        gsm_ids = gsm_ids[: min(len(gsm_ids), 70)]
        for gsm_id in gsm_ids:
            time.sleep(delay)
            gsm_url = f"{BASE_URL}{gsm_id}"
            response = send_request(gsm_url, max_retries, delay)
            if response is None:
                continue

            soup = BeautifulSoup(response.content, "html.parser")
            start = soup.text.find("Title")
            end = soup.text.find("Submission date")

            if start == -1 or end == -1:
                logging.error("Required text not found in the webpage")
                continue

            gsm_text = soup.text[start:end].strip()
            gsm_text = " ".join(
                word for word in gsm_text.split() if word not in REMOVE_WORDS
            )
            text_blob += f"{gsm_id}: \n{gsm_text}\n"

    else:
        start = soup.text.find("Title")
        end = soup.text.find("Submission date")

        if start == -1 or end == -1:
            logging.error("Required text not found in the webpage")
            return None

        text_blob = soup.text[start:end]

    return text_blob


def fetch_geo_overall_design(gse_id, max_retries=3, delay=0.5):
    """
    Fetches the 'Overall design' section text from the GEO (Gene Expression Omnibus) webpage of a given dataset.

    This function sends an HTTP request to the GEO webpage corresponding to the provided GSE (GEO Series) ID.
    It then parses the HTML response to extract the text between the 'Overall design' and 'Contributor(s)'
    sections. If the specified text is not found, it logs an error and returns None.

    Args:
        gse_id (str): The GEO Series ID for which the overall design text is to be fetched.
        max_retries (int, optional): The maximum number of retries for the HTTP request in case of failure.
                                        Defaults to 3.
        delay (float, optional): The delay in seconds between retries. Defaults to 0.5.

    Returns:
        str or None: The extracted 'Overall design' text from the GEO webpage if found, otherwise None.

    The function uses a helper function `send_request` to handle the HTTP request and retries. It uses
    BeautifulSoup to parse the HTML content. If the 'Overall design' section is not found, it logs an
    error message indicating the issue.

    Example:
        >>> gse_id = "GSE12345"
        >>> overall_design_text = fetch_geo_overall_design(gse_id)
        >>> print(overall_design_text)
        "Overall design: This study includes a comparison between treated and untreated samples..."
    """
    geo_url = f"{BASE_URL}{gse_id}"

    response = send_request(geo_url, max_retries, delay)
    if response is None:
        return None

    soup = BeautifulSoup(response.content, "html.parser")
    start = soup.text.find("Overall design")
    end = soup.text.find("Contributor(s)")

    if start == -1 or end == -1:
        logging.error("Required text not found in the webpage")
        return None

    return soup.text[start:end].strip()
