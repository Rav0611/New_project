import logging
import re

import numpy as np

logging.basicConfig(level=logging.INFO)
logging.basicConfig(level=logging.ERROR)


def parse_characteristics(s):
    """
    Parses the characteristics string from GEO metadata and converts it into a dictionary.

    Args:
        s (str): The characteristics string from GEO metadata.

    Returns:
        dict: A dictionary with keys and values extracted from the characteristics string.

    The function removes the 'c(' and ')' characters, splits the string by comma, and then
    further splits each item by colon to separate the keys and values. It assumes that each
    item contains a colon and that the key and value are separated by this colon.

    Example:
        >>> characteristics_str = 'c("disease: cancer", "age: 45")'
        >>> parsed = parse_characteristics(characteristics_str)
        >>> print(parsed)
        {'disease': 'cancer', 'age': '45'}
    """
    items = s.replace("c(", "").replace(")", "").replace('"', "").split(", ")
    return {
        item.split(":")[0].strip(): item.split(":")[1].strip()
        for item in items
        if ":" in item
    }


def filter_columns(raw_metadata):
    """
    Filters out unwanted columns from the raw metadata DataFrame based on predefined criteria.

    Args:
        raw_metadata (pd.DataFrame): The DataFrame containing raw metadata.

    Returns:
        pd.DataFrame: A DataFrame with unwanted columns removed.

    The function removes columns that contain specific keywords or match certain names. It retains
    columns that contain the word 'disease' or are titled 'title', and removes columns that match
    any of the keywords in the exclude lists.

    Example:
        >>> raw_metadata = pd.DataFrame({
                'title': ['Sample 1', 'Sample 2'],
                'disease state': ['healthy', 'cancer'],
                'type': ['RNA', 'RNA']
            })
        >>> filtered_metadata = filter_columns(raw_metadata)
        >>> print(filtered_metadata)
        # DataFrame with 'type' column removed.
    """
    exclude_columns = ["status", "lab", "type", "source_name_ch2"]
    exclude_metadata_keywords = [
        "date",
        "_id",
        "library",
        "data_processing",
        "supplemental_files",
        "biosample",
        "_experiment",
        "_count",
        "sample_characteristics",
        "geo_accession",
        "link",
        "contact",
        "supplementary",
        "instrument_model",
        "taxid",
        "organism",
        "relation",
        "label",
        "molecule",
        "subject",
    ]

    filtered_metadata = raw_metadata[
        [
            column
            for column in raw_metadata.columns
            if column == "title"
            or "disease" in column.lower()
            or all(
                keyword.lower() not in column.lower()
                for keyword in exclude_metadata_keywords
            )
            and "supplementary" not in column
        ]
    ]
    filtered_metadata = filtered_metadata.drop(
        columns=[
            col
            for col in exclude_columns
            if col != "title" and "disease" not in col.lower()
        ],
        errors="ignore",
    )

    return filtered_metadata


def apply_transformations(df):
    """
    Applies a series of transformations to clean and standardize the metadata DataFrame.

    Args:
        df (pd.DataFrame): The DataFrame to be transformed.

    Returns:
        pd.DataFrame: The transformed DataFrame.

    The function applies transformations such as truncating long strings, extracting text after
    colons, removing specific keywords, splitting on equals signs, and sorting columns by length.

    Example:
        >>> df = pd.DataFrame({'info': ['long text: more than 80 characters...', 'Keywords = example']})
        >>> transformed_df = apply_transformations(df)
        >>> print(transformed_df)
        # DataFrame with cleaned and standardized text.
    """
    df = df.applymap(
        lambda x: " ".join(str(x)[:80].split()[:-1]) if len(str(x)) > 80 else x
    )
    df = df.applymap(
        lambda x: re.search(r":\s*(.*)", str(x))[1]
        if re.search(r":\s*(.*)", str(x))
        else x
    )
    df = df.applymap(lambda x: re.sub(r"^Keywords = ", "", str(x)))
    df = df.applymap(lambda x: str(x).split("=")[-1] if "=" in str(x) else x)
    df = df.sort_index(axis=1, key=lambda x: x.str.len())
    return df


def reorder_columns(df, title_column):
    """
    Reorders columns in the DataFrame, ensuring 'title' and 'disease' columns are at the front.

    Args:
        df (pd.DataFrame): The DataFrame whose columns are to be reordered.
        title_column (pd.Series): The 'title' column to be inserted into the DataFrame.

    Returns:
        pd.DataFrame: The DataFrame with reordered columns.

    The function ensures that the 'title' column is the first column in the DataFrame. If a 'disease'
    column exists, it is placed second. The function also cleans the DataFrame by replacing 'none'
    and 'nan' with 'None', and removes commas from strings.

    Example:
        >>> df = pd.DataFrame({'A': ['value1', 'value2'], 'disease': ['cancer', 'healthy']})
        >>> title_col = pd.Series(['Title 1', 'Title 2'], name='title')
        >>> reordered_df = reorder_columns(df, title_col)
        >>> print(reordered_df)
        # DataFrame with 'title' as the first column and 'disease' as the second.
    """
    if "title" not in df.columns:
        df.insert(0, "title", title_column)

    if df.columns[0] != "title":
        title_col = df.pop("title")
        df.insert(0, "title", title_col)

    disease_cols = [
        col for col in df.columns if "disease" in col.lower() and col != "title"
    ]
    if disease_cols:
        disease_col = min(disease_cols, key=len)
        df_columns = [col for col in df.columns if col not in ["title", disease_col]][
            :2
        ]
        df = df[["title", disease_col] + df_columns]

    df = df.replace({"none": np.nan, "nan": np.nan})
    df = df.applymap(lambda x: str(x).replace(",", "") if "," in str(x) else x)
    df = df.replace(np.nan, "None")
    df = df.replace("nan", "None")
    return df


def handle_file_formats(df):
    """
    Removes the 'description' column if it predominantly contains file format extensions.

    Args:
        df (pd.DataFrame): The DataFrame to be processed.

    Returns:
        pd.DataFrame: The DataFrame with the 'description' column removed if necessary.

    The function checks if the 'description' column exists and if more than half of its entries
    end with common file format extensions. If so, the 'description' column is dropped.

    Example:
        >>> df = pd.DataFrame({'description': ['sample.txt', 'data.csv']})
        >>> processed_df = handle_file_formats(df)
        >>> print(processed_df)
        # DataFrame with 'description' column removed.
    """
    file_formats = [".txt", ".csv", ".xlsx", ".xls", ".json", ".xml"]
    if (
        "description" in df.columns
        and df["description"]
        .apply(lambda x: any(str(x).endswith(fmt) for fmt in file_formats))
        .mean()
        > 0.5
    ):
        df = df.drop(columns="description")
    return df


def clean_metadata(raw_metadata):
    """
    Cleans the raw metadata DataFrame by applying various filtering and transformation functions.

    Args:
        raw_metadata (pd.DataFrame): The DataFrame containing raw metadata.

    Returns:
        pd.DataFrame: The cleaned metadata DataFrame.

    The function sequentially applies several cleaning steps to the raw metadata DataFrame, including
    filtering out unwanted columns, applying text transformations, reordering columns, and handling
    file formats. The result is a standardized and clean metadata DataFrame ready for analysis.

    Example:
        >>> raw_metadata = pd.DataFrame({
                'title': ['Sample 1', 'Sample 2'],
                'disease state': ['healthy', 'cancer'],
                'description': ['sample.txt', 'data.csv']
            })
        >>> cleaned_metadata = clean_metadata(raw_metadata)
        >>> print(cleaned_metadata)
        # DataFrame with cleaned and standardized metadata.
    """
    title_column = raw_metadata["title"].copy()
    cleaned_metadata = filter_columns(raw_metadata)
    cleaned_metadata = apply_transformations(cleaned_metadata)
    cleaned_metadata = reorder_columns(cleaned_metadata, title_column)
    cleaned_metadata = handle_file_formats(cleaned_metadata)
    return cleaned_metadata
