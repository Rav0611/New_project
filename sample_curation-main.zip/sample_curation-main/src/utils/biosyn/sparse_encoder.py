import logging
import pickle

import torch
from sklearn.feature_extraction.text import TfidfVectorizer


class SparseEncoder(object):
    """
    A class that encapsulates the TF-IDF vectorization logic for encoding text data into sparse vectors.

    This class uses the TfidfVectorizer from scikit-learn to convert a collection of raw text documents
    to a matrix of TF-IDF features. It is specifically set to analyze characters, which allows it to
    capture subword information. The class can be used to fit a corpus during training and then transform
    any text into vectors using the learned vocabulary. It also provides the option to use CUDA for
    GPU acceleration.

    Attributes:
        encoder (TfidfVectorizer): The vectorizer instance that converts text to TF-IDF feature vectors.
        use_cuda (bool): A flag indicating whether to use CUDA for GPU acceleration.

    Methods:
        fit(train_corpus): Fits the TF-IDF vectorizer to the training corpus.
        transform(mentions): Transforms a list of mentions to their corresponding TF-IDF feature vectors.
        cuda(): Sets the encoder to use CUDA.
        cpu(): Sets the encoder to use CPU.
        __call__(mentions): Transforms mentions to TF-IDF feature vectors (syntactic sugar for transform).
        vocab(): Returns the vocabulary_ attribute of the encoder.
        save_encoder(path): Saves the fitted encoder to the specified path.
        load_encoder(path): Loads the encoder from the specified path.

    Example:
        >>> train_corpus = ['This is a sample document.', 'This document is the second sample.']
        >>> encoder = SparseEncoder(use_cuda=False)
        >>> encoder.fit(train_corpus)
        >>> mentions = ['A new document.']
        >>> vectors = encoder(mentions)
        >>> print(vectors)
        # Output will be a numpy array representing the TF-IDF encoded vector of the input mentions.
    """

    def __init__(self, use_cuda=False):
        self.encoder = TfidfVectorizer(analyzer="char", ngram_range=(1, 2))
        self.use_cuda = use_cuda

    def fit(self, train_corpus):
        self.encoder.fit(train_corpus)
        return self

    def transform(self, mentions):
        vec = self.encoder.transform(mentions).toarray()
        vec = torch.FloatTensor(vec)  # return torch float tensor
        if self.use_cuda:
            vec = vec.cuda()
        return vec

    def cuda(self):
        self.use_cuda = True

        return self

    def cpu(self):
        self.use_cuda = False
        return self

    def __call__(self, mentions):
        return self.transform(mentions)

    def vocab(self):
        return self.encoder.vocabulary_

    def save_encoder(self, path):
        with open(path, "wb") as fout:
            pickle.dump(self.encoder, fout)
            logging.info("Sparse encoder saved in {}".format(path))

    def load_encoder(self, path):
        with open(path, "rb") as fin:
            self.encoder = pickle.load(fin)
            logging.info("Sparse encoder loaded from {}".format(path))

        return self
