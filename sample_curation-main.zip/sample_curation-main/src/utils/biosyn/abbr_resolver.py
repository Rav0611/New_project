import subprocess


class Abbr_resolver:
    """
    A class to resolve abbreviations in biomedical text using the Ab3P tool.

    Attributes:
        ab3p_path (str): The file system path to the Ab3P executable.

    Methods:
        resolve(corpus_path): Runs the Ab3P tool on the specified corpus and returns a dictionary
                                mapping short forms (abbreviations) to their long forms (full phrases).
    """

    def __init__(self, ab3p_path):
        """
        Initializes the Abbr_resolver with the path to the Ab3P executable.
        """
        self.ab3p_path = ab3p_path

    def resolve(self, corpus_path):
        """
        Resolves abbreviations in the given corpus using the Ab3P tool.

        This method executes the Ab3P tool on the corpus located at the specified path. It captures
        the output, processes it, and returns a dictionary of abbreviations and their resolutions.

        Args:
            corpus_path (str): The file system path to the corpus on which abbreviation resolution
                                    is to be performed.

        Returns:
            dict: A dictionary where keys are abbreviations (short forms) and values are the
                    corresponding full phrases (long forms).

        Raises:
            Exception: If the Ab3P tool encounters an error such as a missing path file, an inability
                        to open the necessary files, or other file access issues.

        The method decodes the output from the Ab3P tool, checks for common error messages, and raises
        an exception if any are found. Otherwise, it parses the output to extract abbreviation resolutions
        and returns them in a dictionary.

        Example:
            >>> abbr_resolver = Abbr_resolver(ab3p_path='/path/to/Ab3P')
            >>> result = abbr_resolver.resolve(corpus_path='/path/to/corpus.txt')
            >>> print(result)
            {'SF': 'Short Form', 'LF': 'Long Form'}  # Example output with abbreviations resolved.
        """
        result = subprocess.run(
            [self.ab3p_path, corpus_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        line = result.stdout.decode("utf-8")
        if "Path file for type cshset does not exist!" in line:
            raise Exception(line)
        elif "Cannot open" in line:
            raise Exception(line)
        elif "failed to open" in line:
            raise Exception(line)
        lines = line.split("\n")
        result = {}
        for line in lines:
            if len(line.split("|")) == 3:
                sf, lf, _ = line.split("|")
                sf = sf.strip()
                lf = lf.strip()
                result[sf] = lf

        return result
