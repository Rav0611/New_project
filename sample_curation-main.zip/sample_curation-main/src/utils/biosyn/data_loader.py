import logging

import numpy as np
import pandas as pd
from torch.utils.data import Dataset

LOGGER = logging.getLogger(__name__)


class QueryDataset(Dataset):
    """
    A PyTorch Dataset class for loading training mentions from a CSV file.

    Attributes:
        data (np.array): An array of mention and CUI (Concept Unique Identifiers) pairs.

    Methods:
        load_data(path): Loads mention and CUI pairs from the CSV file at the given path.

    Example:
        >>> dataset = QueryDataset(path='path/to/training_mentions.csv')
        >>> for mention, cui in dataset:
        >>>     print(mention, cui)
    """

    def __init__(self, path):
        """
        Parameters
        ----------
        path : str
            path to csv file containing training mentions
        """

        self.data = self.load_data(path)

    def load_data(self, path):
        """
        Parameters
        ----------
        path : str
            path of data

        Returns
        -------
        data : np.array
            mention, cui pairs
        """
        data = []

        df = pd.read_csv(path)
        for _, row in df.iterrows():
            data.append((row["mention"], row["cui"]))

        # return np.array data
        data = np.array(data)

        return data


class DictionaryDataset:
    """
    A class used to load dictionary data from a CSV file.

    Attributes:
        data (np.array): An array of name and CUI pairs from the dictionary.

    Methods:
        load_data(dictionary_path): Loads name and CUI pairs from the CSV file at the given path.

    Example:
        >>> dictionary_dataset = DictionaryDataset(dictionary_path='path/to/dictionary.csv')
        >>> for name, cui in dictionary_dataset.data:
        >>>     print(name, cui)
    """

    def __init__(self, dictionary_path):
        """
        Parameters
        ----------
        dictionary_path : str
            The path of the dictionary
        """
        LOGGER.info("DictionaryDataset! dictionary_path={}".format(dictionary_path))
        self.data = self.load_data(dictionary_path)

    def load_data(self, dictionary_path):
        data = []
        dict_df = pd.read_csv(dictionary_path)
        for _, row in dict_df.iterrows():
            data.append((row["name"], row["cui"]))

        data = np.array(data)
        return data


class CandidateDataset(Dataset):
    """
    A PyTorch Dataset class for retrieving top-k candidates based on sparse/dense embedding.

    Attributes:
        query_names (list): A list of query names.
        query_ids (list): A list of query IDs.
        dict_names (list): A list of dictionary names.
        dict_ids (list): A list of dictionary IDs.
        topk (int): The number of candidates to retrieve.
        n_dense (int): The number of dense candidates from top-k.
        n_sparse (int): The number of sparse candidates from top-k.
        tokenizer (BertTokenizer): A tokenizer for dense embedding.
        max_length (int): The maximum token length for the tokenizer.
        s_score_matrix (np.array): The sparse score matrix.
        s_candidate_idxs (np.array): The sparse candidate indices.
        d_candidate_idxs (np.array): The dense candidate indices.

    Methods:
        set_dense_candidate_idxs(d_candidate_idxs): Sets the dense candidate indices.
        __getitem__(query_idx): Retrieves the item at the specified query index.
        __len__(): Returns the length of the dataset.
        check_label(query_id, candidate_id_set): Checks if the query ID matches the candidate ID set.
        get_labels(query_idx, candidate_idxs): Retrieves the labels for the given query index and candidate indices.

    Example:
        >>> queries = [('name1', 'id1'), ('name2', 'id2')]
        >>> dicts = [('dict_name1', 'dict_id1'), ('dict_name2', 'dict_id2')]
        >>> tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
        >>> candidate_dataset = CandidateDataset(queries, dicts, tokenizer, max_length=128, topk=10, d_ratio=0.5, s_score_matrix=np.array(...), s_candidate_idxs=np.array(...))
        >>> for data, labels in candidate_dataset:
        >>>     print(data, labels)
    """

    def __init__(
        self,
        queries,
        dicts,
        tokenizer,
        max_length,
        topk,
        d_ratio,
        s_score_matrix,
        s_candidate_idxs,
    ):
        """
        Retrieve top-k candidates based on sparse/dense embedding
        Parameters
        ----------
        queries : list
            A list of tuples (name, id)
        dicts : list
            A list of tuples (name, id)
        tokenizer : BertTokenizer
            A BERT tokenizer for dense embedding
        topk : int
            The number of candidates
        d_ratio : float
            The ratio of dense candidates from top-k
        s_score_matrix : np.array
        s_candidate_idxs : np.array
        """
        LOGGER.info(
            "CandidateDataset! len(queries)={} len(dicts)={} topk={}"
            " d_ratio={}".format(len(queries), len(dicts), topk, d_ratio)
        )
        self.query_names, self.query_ids = [row[0] for row in queries], [
            row[1] for row in queries
        ]
        self.dict_names, self.dict_ids = [row[0] for row in dicts], [
            row[1] for row in dicts
        ]
        self.topk = topk
        self.n_dense = int(topk * d_ratio)
        self.n_sparse = topk - self.n_dense
        self.tokenizer = tokenizer
        self.max_length = max_length

        self.s_score_matrix = s_score_matrix
        self.s_candidate_idxs = s_candidate_idxs
        self.d_candidate_idxs = None

    def set_dense_candidate_idxs(self, d_candidate_idxs):
        self.d_candidate_idxs = d_candidate_idxs

    def __getitem__(self, query_idx):
        assert self.s_candidate_idxs is not None
        assert self.s_score_matrix is not None
        assert self.d_candidate_idxs is not None

        query_name = self.query_names[query_idx]
        query_token = self.tokenizer(
            query_name,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        # combine sparse and dense candidates as many as top-k
        s_candidate_idx = self.s_candidate_idxs[query_idx]
        d_candidate_idx = self.d_candidate_idxs[query_idx]

        # fill with sparse candidates first
        topk_candidate_idx = s_candidate_idx[: self.n_sparse]

        # fill remaining candidates with dense
        for d_idx in d_candidate_idx:
            if len(topk_candidate_idx) >= self.topk:
                break
            if d_idx not in topk_candidate_idx:
                topk_candidate_idx = np.append(topk_candidate_idx, d_idx)

        # sanity check
        assert len(topk_candidate_idx) == self.topk
        assert len(topk_candidate_idx) == len(set(topk_candidate_idx))

        candidate_names = [
            self.dict_names[candidate_idx] for candidate_idx in topk_candidate_idx
        ]
        candidate_s_scores = self.s_score_matrix[query_idx][topk_candidate_idx]
        labels = self.get_labels(query_idx, topk_candidate_idx).astype(np.float32)

        candidate_tokens = self.tokenizer(
            candidate_names,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        return (query_token, candidate_tokens, candidate_s_scores), labels

    def __len__(self):
        return len(self.query_names)

    def check_label(self, query_id, candidate_id_set):
        label = 0
        query_ids = query_id.split("|")
        """
        All query ids should be included in dictionary id
        """
        for q_id in query_ids:
            if q_id in candidate_id_set:
                label = 1
                continue
            else:
                label = 0
                break
        return label

    def get_labels(self, query_idx, candidate_idxs):
        labels = np.array([])
        query_id = self.query_ids[query_idx]
        candidate_ids = np.array(self.dict_ids)[candidate_idxs]
        for candidate_id in candidate_ids:
            label = self.check_label(query_id, candidate_id)
            labels = np.append(labels, label)
        return labels
