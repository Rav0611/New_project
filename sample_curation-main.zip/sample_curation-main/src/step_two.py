# Standard library imports
import argparse
import copy
import json
import os
import warnings
from collections import defaultdict

# Third-party imports
import openai
import pandas as pd
from dotenv import load_dotenv

from gpt_biomedical_named_entity_recognition import (
    generate_specific_biomedical_named_entity_recognition_with_chatgpt,
    generate_system_prompt_for_specific_biomedical_named_entity_recognition,
    generate_user_prompt_for_specific_biomedical_named_entity_recognition,
)
from gpt_sample_mappings_and_association import (
    generate_sample_mappings_and_association_with_chatgpt,
    generate_system_prompt_for_sample_mappings_and_association,
    generate_user_prompt_for_sample_mappings_and_association,
)

# Local application imports
from utils.cleanup_metadata import clean_metadata
from utils.extract_text_from_remaining_sections_of_paper import (
    extract_remaining_text_sections,
)
from utils.upload_polly_workspace import Workspaces

# Load environment variables
load_dotenv()
openai.api_key = os.getenv("OPENAI_KEY")

# Suppress warnings if necessary
warnings.filterwarnings("ignore")

# Initialize workspace and other configurations
token = os.getenv("POLLY_TOKEN")
workspace_id = int(os.getenv("WORKSPACE_ID"))
workspaces = Workspaces(token)

# Argument parsing for command-line utility
parser = argparse.ArgumentParser(description="Process some dataset IDs.")
parser.add_argument(
    "file_path", type=str, help="Location of the file containing the dataset IDs"
)
args = parser.parse_args()

with open(args.file_path, "r") as file:
    process_dataset_ids = json.load(file)


def dataframe_to_str_dict(df):
    """
    Converts a pandas DataFrame into a dictionary with string representations of each row.

    This function takes a DataFrame and converts each row into a space-separated string of its values,
    excluding any 'nan' values. The resulting strings are sorted based on the original order of values
    in the row. The DataFrame index is used as the key for the dictionary.

    Args:
        df (pd.DataFrame): The DataFrame to convert. The index of the DataFrame is preserved as keys
                            in the output dictionary.

    Returns:
        dict: A dictionary where each key is the DataFrame index and each value is a space-separated
                string of the non-NaN values from the corresponding row in the DataFrame.

    Example:
        Given a DataFrame like this:
            A      B      C
        0  foo    bar    NaN
        1  baz    qux    quux

        The resulting dictionary would be:
        {
            0: 'foo bar',
            1: 'baz qux quux'
        }
    """
    return {
        row.Index: " ".join(
            sorted(
                {str(value) for value in row[1:] if str(value).lower() != "nan"},
                key=row[1:].index,
            )
        )
        for row in df.itertuples()
    }


def process_sample_level_associations(mappings):
    """
    Processes sample-level associations and returns a DataFrame with the associations.

    This function takes a dictionary of mappings that associates various attributes to sample IDs.
    It processes these mappings to consolidate the information into a structured format, suitable
    for further analysis or export. The output is a pandas DataFrame where each row corresponds to
    a sample ID and each column represents a specific attribute, prefixed with 'gpt_'.

    The attributes include disease, cell line, cell type, tissue, drug, concentration of drug,
    time point of drug, gene symbol, and genetic perturbation type. If an attribute has multiple
    values for a single sample ID, they are concatenated with a '+' symbol.

    Args:
        mappings (dict): A dictionary where keys are attribute names (e.g., 'drug', 'disease') and
                        values are dictionaries mapping attribute values to lists of sample IDs.

    Returns:
        pd.DataFrame: A pandas DataFrame with sample IDs as the index and GPT attributes as columns.
                        The DataFrame is sorted by sample IDs.

    Example:
        Input mappings might look like this:
        {
            "disease": {"cancer": ["GSM1", "GSM2"], "diabetes": ["GSM3"]},
            "drug": {"drugA": ["GSM1"], "drugB": ["GSM1", "GSM2"]},
            ...
        }

        The resulting DataFrame would have rows for GSM1, GSM2, GSM3, etc., and columns for
        gpt_disease, gpt_drug, etc., with the associated values filled in.
    """
    output_dict = defaultdict(
        lambda: {
            "gpt_disease": None,
            "gpt_cell_line": None,
            "gpt_cell_type": None,
            "gpt_tissue": None,
            "gpt_drug": None,
            "gpt_treatment": None,
            "gpt_donor": None,
            "gpt_gene": None,
            "gpt_gene_modification": None,
        }
    )

    for attr, dic in mappings.items():
        dic_cp = copy.deepcopy(dic)
        for value, sample_ids in dic_cp.items():
            if sample_ids is None:
                sample_ids = []
            for sample_id in sample_ids:
                if attr == "drug":
                    if output_dict[sample_id][f"gpt_{attr}"] is None:
                        output_dict[sample_id][f"gpt_{attr}"] = value
                    else:
                        output_dict[sample_id][f"gpt_{attr}"] += "+" + value
                else:
                    output_dict[sample_id][f"gpt_{attr}"] = value

    final_dataframe = (
        pd.DataFrame(output_dict)
        .T.reset_index()
        .rename(columns={"index": "GSM_ID"})
        .set_index("GSM_ID")
    )
    final_dataframe = final_dataframe.sort_index()
    return final_dataframe


def process_dataset_and_save(dataset_ids):
    
    base_dir = "/app/data/dataset_info/"
    os.makedirs(base_dir, exist_ok=True)
    os.makedirs("/app/data/", exist_ok=True)
    os.makedirs("/app/data/sample_level_metadata/", exist_ok=True)

    file_path = "/app/data/dataset_info/paper_mappings.json"
    with open(file_path, "r") as json_file:
        loaded_dict = json.load(json_file)

    for dataset_id in dataset_ids:
        raw_metadata_path = (
            f"/app/data/raw_sample_level_metadata/{dataset_id}.csv"
            )
        try:
            raw_sample_level_metadata_df = pd.read_csv(raw_metadata_path).set_index(
                "GSM_ID"
            )
        except Exception as e:
            print(
                f"Error reading raw sample level metadata for dataset ID {dataset_id}: {e}"
            )

        dataset_dict = {
            "dataset_id": dataset_id,
            "paper": {},
            "unique_sample_level_metadata": "",
            "geo_info": "",
            "raw_sample_level_metadata": "",
        }

        required_pmc_ids = list(set(loaded_dict.get(dataset_id, [])))

        for pmcid in required_pmc_ids:
            json_path = f"/app/data/dataset_info/{pmcid}.json"
            paper_info = {}

            try:
                with open(json_path, "r", encoding="utf-8") as json_file:
                    paper_info = json.load(json_file)
            except FileNotFoundError:
                print(f"File not found: {json_path}")
                continue

            paper_dict = dataset_dict["paper"].setdefault(
                pmcid, {"introduction": [], "abstract": [], "method": [], "others": []}
            )
        
            for key, value in paper_info.items():
                if "introduction" in key.lower():
                    paper_dict["introduction"].append(value)
                elif "abstract" in key.lower():
                    paper_dict["abstract"].append(value)
                elif "method" in key.lower():
                    paper_dict["method"].append(value)
                elif "others" in key.lower():
                    pruned_text = extract_remaining_text_sections(str(value))
                    paper_dict["others"].append(pruned_text)

        unique_metadata_path = (
            f"/app/data/unique_sample_metadata/{dataset_id}.json"
        )
        try:
            with open(unique_metadata_path, "r", encoding="utf-8") as json_file:
                dataset_dict["unique_sample_level_metadata"] = json.load(json_file)
        except Exception as e:
            print(
                f"Error reading unique sample metadata for dataset ID {dataset_id}: {e}"
            )

        geo_info_path = f"/app/data/geo_info/{dataset_id}.txt"
        try:
            with open(geo_info_path, "r", encoding="utf-8") as file:
                dataset_dict["geo_info"] = file.read()
        except Exception as e:
            print(f"Error reading GEO info for dataset ID {dataset_id}: {e}")

        raw_metadata_path = (
            f"/app/data/raw_sample_level_metadata/{dataset_id}.csv"
        )
        try:
            raw_sample_level_metadata_df = pd.read_csv(raw_metadata_path).set_index(
                "GSM_ID"
            )
            cleaned_sample_level_metadata = clean_metadata(raw_sample_level_metadata_df)
            dataset_dict["raw_sample_level_metadata"] = dataframe_to_str_dict(
                cleaned_sample_level_metadata
            )
        except Exception as e:
            print(
                f"Error reading raw sample level metadata for dataset ID {dataset_id}: {e}"
            )

        selected_paper_key = next(iter(dataset_dict["paper"]), None)
        if selected_paper_key:
            selected_paper = dataset_dict["paper"][selected_paper_key]
            introduction_text = selected_paper.get("introduction", "")
            abstract_text = selected_paper.get("abstract", "")
            method_text = selected_paper.get("method", "")
            others_text = selected_paper.get("others", "")
            unique_sample_level_metadata = dataset_dict.get(
                "unique_sample_level_metadata", {}
            )
            geo_info = dataset_dict.get("geo_info", "")
        else:
            introduction_text = ""
            abstract_text = ""
            method_text = ""
            others_text = ""
            unique_sample_level_metadata = {}
            geo_info = ""

        system_prompt_for_specific_biomedical_named_entity_recognition = (
            generate_system_prompt_for_specific_biomedical_named_entity_recognition()
        )
        user_prompt_for_specific_biomedical_named_entity_recognition = (
            generate_user_prompt_for_specific_biomedical_named_entity_recognition(
                introduction=introduction_text,
                abstract=abstract_text,
                method=method_text,
                other_sections=others_text,
                unique_sample_level_metadata=unique_sample_level_metadata,
                geo_info=geo_info,
            )
        )
        biomedical_ner = generate_specific_biomedical_named_entity_recognition_with_chatgpt(
            system_prompt=system_prompt_for_specific_biomedical_named_entity_recognition,
            user_prompt=user_prompt_for_specific_biomedical_named_entity_recognition,
        )
        
        final_dataset_mappings = defaultdict(lambda: defaultdict(list))
        
        chunk_size = 20
        dataset_mappings = []

        raw_sample_level_metadata_dataframe = dataset_dict["raw_sample_level_metadata"]
        metadata_items = list(raw_sample_level_metadata_dataframe.items())
        total_chunks = len(metadata_items) // chunk_size + (1 if len(metadata_items) % chunk_size else 0)

        for chunk_index in range(total_chunks):
            start = chunk_index * chunk_size
            end = start + chunk_size
            metadata_chunk = dict(metadata_items[start:end])
            
            system_prompt = generate_system_prompt_for_sample_mappings_and_association()
            user_prompt = generate_user_prompt_for_sample_mappings_and_association(
                geo_info=geo_info,
                metadata_dict=metadata_chunk,
                gpt_ner=biomedical_ner,
            )
            chunk_mappings = generate_sample_mappings_and_association_with_chatgpt(
                system_prompt_text=system_prompt,
                prompt_text=user_prompt,
            )
            
            dataset_mappings.append(chunk_mappings)

        
        for chunk_mapping in dataset_mappings:
            for entity_type, entity_values in chunk_mapping.items():
                for value, ids in entity_values.items():
                    final_dataset_mappings[entity_type][value].extend(ids)

        final_dataset_mappings = {k: dict(v) for k, v in final_dataset_mappings.items()}
        
        print('all final_dataset_mappings')
        print(final_dataset_mappings)
        
        final_data_frame = process_sample_level_associations(mappings=final_dataset_mappings)
        print('final_data_frame')
        print(final_data_frame)
        curated_sample_level_metadata_path = f"/app/results/{dataset_id}/step_three_curated_sample_level_metadata.csv"
        os.makedirs(os.path.dirname(curated_sample_level_metadata_path), exist_ok=True)
        final_data_frame.to_csv(curated_sample_level_metadata_path)
        workspaces.upload_to_workspaces(
            workspace_id=workspace_id,
            workspace_path=f"polly://curation_output/{dataset_id}/intermediate_steps/{dataset_id}_curated_from_extracted_tags_without_ontology_mapping_sample_level_metadata.csv",
            local_path=curated_sample_level_metadata_path,
        )

        dataset_dict_json_path = (
            f"/app/results/{dataset_id}/dataset_dict.json"
        )
        os.makedirs(os.path.dirname(dataset_dict_json_path), exist_ok=True)
        with open(dataset_dict_json_path, "w", encoding="utf-8") as json_file:
            json.dump(dataset_dict, json_file, ensure_ascii=False, indent=4)
        workspaces.upload_to_workspaces(
            workspace_id=workspace_id,
            workspace_path=f"polly://curation_output/{dataset_id}/intermediate_steps/{dataset_id}_all_dataset_information_in_json_format.json",
            local_path=dataset_dict_json_path,
        )

        biomedical_ner_json_path = (
            f"/app/results/{dataset_id}/biomedical_ner.json"
        )
        os.makedirs(os.path.dirname(biomedical_ner_json_path), exist_ok=True)
        with open(biomedical_ner_json_path, "w", encoding="utf-8") as json_file:
            json.dump(biomedical_ner, json_file, ensure_ascii=False, indent=4)
        workspaces.upload_to_workspaces(
            workspace_id=workspace_id,
            workspace_path=f"polly://curation_output/{dataset_id}/intermediate_steps/{dataset_id}_biomedical_ner.json",
            local_path=biomedical_ner_json_path,
        )

process_dataset_and_save(process_dataset_ids)
