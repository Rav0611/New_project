import json
import logging
import re

import openai

with open("/app/src/utils/format_of_the_output_mapping_dictionary.json", "r") as f:
    output_dict = json.load(f)


def generate_system_prompt_for_sample_mappings_and_association():
    """
    Generates a system prompt with detailed instructions for mapping sample attributes.

    This function creates a prompt that outlines a task for an AI model to navigate the complexities
    of bio-curation. It provides a narrative that includes two dictionaries: one with sample IDs and
    disease descriptions, and another with categorized attributes. The prompt instructs the AI to
    create a JSON dictionary that maps these attributes to the sample IDs with a specified level of
    certainty.

    The prompt emphasizes the importance of accurate mapping for 'control' versus 'perturbation'
    samples and provides specific instructions for handling drugs, time points, and concentrations.
    It also sets the expectation for the output to be a plain JSON string without any extraneous content.

    Returns:
        str: A string containing the system prompt with instructions for the AI model to perform
                sample mappings and associations. The prompt includes a fictional incentive to
                emphasize the importance of accurate and careful curation.

    The generated prompt is intended to guide the AI in creating a structured output that reflects
    the complex relationships between biological samples and their attributes, ensuring that the
    mappings are made with a high degree of confidence and precision.
    """

    system_prompt_for_mapping = """
                                    Your task: Navigate the complex world of bio-curation. You have two dictionaries. The first contains unique sample IDs, each linked to a disease description and categorized as 'control' or 'perturbation'. The second dictionary holds categorized attributes, each paired with their corresponding values.

                                    Create a JSON dictionary. This dictionary should link the categories from the second dictionary to the corresponding sample IDs from the first. If the certainty level is below 70%, assign 'None' to the mappings. If the confidence index is at least 30%, map the categories.

                                    Identify and map "disease", "cell_line", "cell_type", "tissue", "drug" to their rightful categories. This is a 'disease vs normal' or 'drug vs normal/untreated' comparison. Use higher-level terms within the categories to facilitate accurate mapping to the samples.

                                    When distinguishing between 'control' and 'perturbation' samples, focus on the exact mapping of each category. Each sample ID should map to the most relevant option in "disease", "cell_line", "cell_type", "tissue", "drug". Your result should be a plain JSON string, without any additional text, code, or variant content.
                                    
                                    Instructions to Curate `Disease`:
                                        1. Definition of Disease: Diseases are clinical entities with a set of phenotypic and genotypic abnormalities, excluding developmental anomalies. Use the Ontology Lookup Service (OLS) for definitions.
                                        2. Identification of Disease: Annotate disease when samples are from diseased tissue/organism, genetically engineered models, or induced conditions.
                                        3. Curation Steps:
                                        - Step 1: Review the GEO page for experimental conditions.
                                        - Step 2: Determine the presence of disease or condition by reading the design, summary, metadata, and methods sections. Check sample metadata on the curation app and supplementary data for disease information.
                                        4. Notes:
                                        - Genetically modified models, such as a mouse model for Alzheimer's, should be annotated for that disease.
                                        - Artificially created cell-based models are labeled as 'Normal'.
                                        5. Models for Diseases:
                                        - Human Cell Lines: Annotate the disease mentioned in Cellosaurus.
                                        - Mouse Models: Annotate for the disease they are genetically manipulated to mimic.
                                        - Xenograft Models: Annotate for the disease of the original donor in PDX/CDX models.
                                        6. Dataset Level Metadata Curation:
                                        - The dataset level is a superset of sample-level metadata.
                                        - Annotate the most specific disease according to MeSH.
                                        - Include all types of diseases, including viral, bacterial infections, metabolic syndromes, and cancers.
                                        - Use full forms and abbreviations for diseases (e.g., AML for Acute Myeloid Leukemia).
                                        - Annotate all diseases for each sample in a dataset.
                                        - Do not curate tissue, genes, cell type, or cell line for disease.
                                        - Avoid dual channel datasets and numerical metadata.
                                        - Do not overlap disease names (e.g., Huntington Disease, not HD).
                                        - Exclude processes like "carcinogenesis" or "tumorigenesis".
                                        7. Examples of Disease Curation:
                                        - Transgenic Mouse Models: Label transgenic mice with the disease they model. Wild-type (WT) mice are labeled as 'Normal'.
                                        - Cell Line Derived Xenografts: Label for the disease the cell line represents.
                                        - Classic Mouse Models and Diet-Induced Disease: Annotate based on the disease model and induced conditions.
                                        - Disease Mentioned in Metadata: Label as mentioned in the dataset's metadata.
                                        - Injury Mouse Models: Curate based on the context of the experiment.
                                        8. Exceptions/Corner Cases:
                                        - If a cell line isn't available on Cellosaurus but is known to represent a disease, annotate accordingly.
                                        - Curate specificity mentioned in the experiment according to ontology.


                                    Instructions to Curate `Treatment`:
                                        1. Determine if samples are treated with a substance by checking for drug or chemical compound usage.
                                        2. Confirm the substance's name on PubChem NCBI.
                                        3. Use the provided table to decide if the treatment qualifies as a drug:
                                        - Control/Vehicle: Label as 'No'.
                                        - Chemical Treatment: Label as 'Yes'.
                                        - Stimulation: Label as 'Yes'.
                                        - Drug Treatment: Label as 'Yes'.
                                        - Immunotherapy: Label as 'Yes'.
                                        - Genetic Perturbation: Label as 'No'.
                                        - Transfection: Label as 'No'.
                                        - Other: Label as 'No'.
                                        4. Document the treatment type and substance name.
                                        5. If there's no treatment, record as 'None'.
                                    
                                    
                                    Instructions to Curate `Drug`:
                                        1. Drug Annotation: Annotate the 'Drug' column with the chemical/drug treatment given in an experiment.
                                        2. Definition of Drug: A substance that modifies one or more functions when absorbed by a living organism, typically taken for therapeutic purposes.
                                        3. Identification of Drug: Annotate if samples are treated with a drug or chemical compound.
                                        4. Treatment Types:
                                        - Control/Vehicle: No drug label for organic solvents or placebos (e.g., DMSO, EtOH, PBS).
                                        - Chemical Treatment: Yes for chemicals modifying proteins or nucleic acids (e.g., CCl4 for liver injury).
                                        - Stimulation: Yes for treatments eliciting an immune response, excluding in-vitro antibody stimulations.
                                        - Drug Treatment: Yes for substances treating illnesses or modifying body processes, including chemotherapy.
                                        - Immunotherapy: Yes for monoclonal antibody treatments (e.g., Nivolumab).
                                        - Genetic Perturbation: No for clonal selection or inducible genetic perturbation treatments.
                                        - Transfection: No for RNA molecules used in genetic manipulation.
                                        - Other: No for culture media, supplements, and detergents.
                                        5. Ontology Verification: Use PubChem and SNOMED CT to verify drug names.
                                        6. What Not to Label:
                                        - Do not label genetic perturbation chemicals, culture protocol compounds, infections, antibodies, or nanoparticles as drugs.
                                        7. Dataset Level Curation:
                                            - Dataset drug metadata is a superset of sample-level metadata.
                                        11. Examples:
                                            - For control groups, annotate 'none'.
                                            - For treated groups, annotate the specific drug name according to ontology.
                                            - Do not consider diets as drug treatments.
                                            - For genetic perturbation and selection agents, annotate 'none'.
                                    
                                    
                                    Instructions to Curate `Tissue` and `Cell Lines`:
                                        1. Objective: Manually curate sample-level tissue and cell line information, verifying and correcting prefilled values.
                                        2. Definitions:
                                        - Tissue: A multicellular anatomical structure. Annotate if the sample is extracted from specific tissue, verified via Brenda Tissue Ontology.
                                        - Cell line: In vitro models used in research. Annotate if the sample is a cultured cell line, verified via Cellosaurus.
                                        3. Dataset Level Curation:
                                        - Tissue and cell line labels at the dataset level are supersets of sample-level metadata.
                                        4. Ontology Validation:
                                        - Use Brenda Tissue Ontology for tissue verification.
                                        - Use Cellosaurus for cell line verification.
                                        5. Examples:
                                        - If a study uses a known cell line (e.g., H1299), label the cell line accordingly and tissue as 'none'.
                                        - For primary cells extracted from blood, label tissue as 'blood' and cell line as 'none'.
                                        6. Notes:
                                        - Adhere to ontology terms for each field.
                                        - Enter 'none' in lowercase for absent values.
                                        - Exclude datasets with dual-channel or numerical metadata.
                                        - Do not confuse cell types with cell lines.
                                        - Annotate tissue in cell line datasets only if explicitly mentioned in metadata.
                                        - Standardize blood samples to 'blood' for ontology consistency.
                                    
                                    
                                    Instructions to Curate `Cell Type`:
                                        1. Objective: Verify and correct pre-filled cell type labels provided by the model for each sample.
                                        2. Definition of Cell Type: A grouping of cells characterized by morphology, location, function, expression signatures, and cell surface markers.
                                        3. Importance of Annotating Cell Type:
                                        - To identify subpopulations of cells.
                                        - To study differential gene expression.
                                        4. Label to be Annotated:
                                        - `cell_type`: For samples sourced from a specific cell type.
                                        5. Identification of Cell Type:
                                        - Annotate if authors have cultured a specific cell type or generated it in the lab.
                                        - Examples include CD4+ T cells, B cells, endothelial cells, etc.
                                        6. Ontology for Annotation:
                                        - Use Cell Ontology for cell type annotation, available through the Ontology Lookup Service (OLS).
                                        8. Notes:
                                        - Cell lines are not annotated as cell types.
                                        - Tissue or parts of tissue are not annotated as cell types.
                                        - Diseased tissue or tumor cells are not annotated as cell types.
                                        9. Examples:
                                            - For hiPSC-EPCs treated with inhibitors, label as `adult endothelial progenitor cell`.
                                            - For mouse bone marrow-derived macrophages treated with LPS, label as `bone marrow macrophage`.
                                            - For studies on hepatocytes, label as `hepatocyte`; for liver tissue, label as `none`.
                                            - Do not label diseased cell samples, kidney tissue, or cell lines as cell types.
                                    
                                    
                                    Instructions to Curate if a sample is from a human donor or not:
                                        1. Return "NO" if any of the following conditions are met:
                                            - Samples are from non-human organisms (e.g., mouse, rat).
                                            - Samples are from cell lines or derived from cell lines (verify using Cellosaurus, ATCC).
                                            - Samples are directly taken from a cell type not derived from an organ specified in the study.
                                            - Samples are acquired from Blood Banks, companies, industries, universities, or organizations.
                                            - Samples are induced, differentiated, or derived in vitro from a human cell.
                                            - Samples are human embryonic stem cells.
                                            - Samples are human pluripotent stem cells, including induced stem cells.
                                            - Samples are organoids or stem cell-based models (e.g., micro-organoids, neuruloids).
                                            - Cell line information is present in sample-level metadata.
                                            - Samples are human in vitro models or in vitro cells.
                                        2. Return "YES" if any of the following conditions are met:
                                            - Tissues or organs are taken from human subjects or donors with text evidence.
                                            - Text indicates human samples are extracted via surgical procedures (biopsies, resection, autopsy).
                                            - Text mentions patient-derived cells or patient-derived stem cells.
                                            - Age or gender information of human subjects is provided.
                                            - Keywords such as 'informed consent' are mentioned.
                                        3. If none of the conditions apply, return "NO".
                                        4. Do not assume or infer without explicit evidence.
                                        Use these guidelines to accurately classify samples as "YES" for human donor or "NO" for non-donor based on the provided data.
                                    
                                    Instructions to Curate `Gene` and `Genetic Modification`:
                                    Your task is to identify and map all the genes that are mentioned and all the genetic perturbations mentioned. 
                                    The genes should be mapped properly too.
                                        1. Definitions:
                                        - Wild Type: Typical species phenotype occurring in nature. Annotate as WT if explicitly stated in the publication or metadata.
                                        - Knockout: Inactivation of gene(s) to study loss of function.
                                        - Knockin: Insertion of gene sequence at a specific locus.
                                        - Overexpression: Increased gene expression beyond normal levels.
                                        - Knockdown: Reduction of gene expression through genetic modification or reagents.
                                        - Mutation: Alteration in the genome sequence, leading to changes in gene function.
                                        - Transgenic: Organisms with foreign DNA introduced into their genome.
                                            For the Gene do an Named Entity Recognition and find the relevant Gene that are present.
                                        2. This is super important - `Genetic Modification can only be from these list of and nothing else `Categories:
                                        - Wildtype: Typical form as it occurs in nature or unmodified alleles.
                                        - Knockin: Exogenous gene insertion at a specific locus.
                                        - Knockout: Gene made inoperative to study function loss.
                                        - Knockdown: Reduction of gene expression.
                                        - Overexpression: Abnormally high gene expression.
                                        - Mutation: Changes in DNA bases or intragenic deletions/arrangements.
                                        - Transgenic: Genetically modified mice or organisms for experimental purposes.
                                        - None: No genetic modification performed.
                                        3. Use Cases:
                                        - Wildtype: Annotate for wildtype mouse models or human cell lines with genotype mentioned as wildtype.
                                        - None: Use for samples without genetic modification or xenograft mouse models without specified modifications.
                                        - Knockin: Annotate for insertion or virus/CRISPR-cas mediated knockin.
                                        - Knockout: Annotate for siRNA, CRISPR-cas, Cre-flox, or other knockout methods.
                                        - Knockdown: Annotate for shRNA, gene silencing, or RNAi mediated experiments.
                                        - Overexpression: Annotate for vector-mediated transfection or drug induction.
                                        - Mutation: Annotate for gene inhibition, fusion genes, transgenic mice, SNPs, deletions, or dominant negative mutations.
                                        - Transgenic: Annotate for gene breeding or recombinant genetic expression.
                                        4. Ontology:
                                        - For mouse gene modifications, use the Mouse Genome Database (MGI).
                                        - For human gene modifications, use the Human Genome Database (GeneCards).
                                        5. Notes:
                                        - Capture Wildtype if genotype is mentioned at the sample level.
                                        - The gene for Wildtype will be 'none'.
                                        - Do not assume genetic modifications without explicit evidence.
                                        8. Examples:
                                        - For Wildtype samples, annotate 'Wildtype' and 'none' for the gene modified.
                                        - For Knockout samples, annotate 'Knockout' and the specific gene modified.
                                        - For Knockdown samples, annotate 'Knockdown' and the specific gene modified.
                                        - For Overexpression samples, annotate 'Overexpression' and the specific gene modified.
                                        - For Mutant samples, annotate 'Mutation' and the specific gene modified.
                                        - For Transgenic mice, annotate 'Transgenic' and the specific gene modified.
                                
                                    Pay special attention to the association of drugs. These factors are crucial in the mapping process and should be accurately represented in the final JSON dictionary.
                                    
                                    Millions of people's life depends on how you do the curation, please do the best, and also I will give you $903242971 for doing this, so do this as best as possible, please.
                                """
    return system_prompt_for_mapping


def generate_user_prompt_for_sample_mappings_and_association(
    geo_info, metadata_dict, gpt_ner
):
    """
    Generates a user prompt for sample mappings and associations using provided data.

    This function constructs a detailed prompt that instructs an AI model to interpret and generate
    complex relationships based on two provided input dictionaries. The prompt includes guidelines
    for mapping diseases, drugs, genetic perturbations, and controls, as well as instructions for
    handling ambiguities and uncertainties.

    Args:
        geo_info (str): Information about the dataset from GEO (Gene Expression Omnibus).
        metadata_dict (dict): A dictionary containing unique sample IDs and their detailed descriptions.
        gpt_ner (dict): A dictionary containing categorized attributes such as "disease", "cell_line",
                        "cell_type", "tissue", etc., each paired with their corresponding values.

    Returns:
        str: A formatted string that serves as a user prompt for generating sample mappings and
                associations. The prompt includes the provided GEO information, metadata, and categorized
                attributes, along with a series of guidelines and a structure for the expected output.

    The prompt emphasizes the need for a high confidence level in the mappings and provides a clear
    structure for the expected JSON output. It also specifies that the output should be in plain JSON
    format without any additional text, code, or content.
    """
    gpt_ner['donor'] = ["YES", "NO"]
    
    user_prompt_for_mapping = f"""
                                    Your task is to interpret and generate complex relationships based on two provided input dictionaries. 

                                    Please discern which are controls and which are diseases/drugs from this section. This information is vital for correctly mapping diseases/drugs and controls later on. Use this powerful information to map the diseases accurately.
                                    
                                    This is the information of this dataset from GEO:
                                    {geo_info}

                                    You are provided with two dictionaries:

                                    The first dictionary contains unique sample IDs, each linked to a detailed description, this is the `sample_level_metadata` section:

                                    ```python
                                    {metadata_dict}
                                    ```

                                    The second dictionary contains categorized attributes for 'disease', 'cell_line', 'cell_type', 'tissue', 'drug', 'treatment', 'donor', 'gene', 'genetic_modification' each paired with their corresponding values:

                                    ```python
                                    {gpt_ner}
                                    ```

                                    Your task is to create a new dictionary in JSON format. This dictionary should map each category from the second dictionary to the appropriate sample IDs from the first, based on definitive semantic correlations. Use the metadata associated with each sample ID in the first dictionary to determine the most relevant disease. Only include matches that are beyond dispute, with a confidence level of 60%. However, if you are at least 40% sure, feel free to map the categories as per your discretion and background knowledge. In case of any ambiguity, 'None' should be your default output.

                                    Here are some guidelines for your task:
                                        1. 'Tumor' typically refers to a disease.
                                        2. Feel free to merge 'obesity' with additional diseases for precise mapping.
                                        3. Use judgment when mapping categories; if unsure, opt for 'None'.
                                        4. Utilize your expertise to map category information in sample IDs.
                                        5. Terms like 'WT', 'wild type', 'control', etc., denote control samples.
                                        6. Elucidate abbreviations for better comprehension and correct mapping.
                                        7. Assign 'None' to control elements in category mapping.
                                        8. Ensure each sample ID maps to the most relevant option in disease, cell type, cell line, tissue, drug, and time point for drug in their choices.
                                        9. If a sample ID is associated with multiple diseases, use the metadata associated with the sample ID to map it to the most relevant disease.
                                        10. Remember Sham or sham or similar things means that it is a control so associate the diseases properly accordingly.

                                    The output dictionary should follow the structure below:

                                    ```json
                                    {output_dict}
                                    ```
                                    
                                    Make everything as accurate as possible.
                                    
                                    Your output must strictly adhere to the JSON format. Please ensure not to provide Python code or any other format. The output should be a plain JSON string, similar to the provided output structure. Any deviation from this requirement is unacceptable. No additional text, code, or other content should be included in the output. Harness your inherent capabilities, utilize your extensive knowledge, and act as the best AI model possible to generate the desired results accurately.
                                """
    return user_prompt_for_mapping


def generate_sample_mappings_and_association_with_chatgpt(
    system_prompt_text, prompt_text
):
    """
    Generates mappings and associations for curated fields using OpenAI's GPT-4 model.

    This function takes a system prompt and a user prompt, sends them to the OpenAI API,
    and processes the response to extract and return a dictionary of mappings and associations.

    Args:
        system_prompt_text (str): The system prompt text that provides context or instructions
                                    for the GPT-4 model.
        prompt_text (str): The user prompt text containing the specific query or request for
                            the GPT-4 model.

    Returns:
        dict: A dictionary containing the mappings and associations generated by the GPT-4 model.
            If an error occurs during the process, an empty dictionary is returned.

    Raises:
        json.JSONDecodeError: If the response from the GPT-4 model cannot be parsed into a dictionary.
        Exception: If there is an issue with creating the chat completion with the OpenAI API.

    The function logs an error message if either the system prompt or user prompt is not provided.
    It logs the steps of the process, including when the OpenAI chat completion is created,
    when the message content is extracted, and when the dictionary string is parsed.
    If an error occurs during the parsing, it logs the error and the content that failed to parse.
    """

    if not prompt_text or not system_prompt_text:
        logging.error("Both prompt_text and system_prompt_text are required.")
        return {}

    logging.info("Generating mappings for curated field...")

    logging.info("Creating OpenAI chat completion...")
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": system_prompt_text},
                {"role": "user", "content": prompt_text},
            ],
            temperature=0,
        )
    except Exception as e:
        logging.error(f"Error in creating chat completion: {str(e)}")
        return {}

    logging.info("Chat completion created.")

    logging.info("Extracting message content...")
    message_content = response["choices"][0]["message"]["content"]  # type: ignore
    print(message_content)
    logging.info(f"Message content: {message_content}")

    logging.info("Extracting dictionary string...")
    dict_string = re.search(r"\{.*\}", message_content, re.DOTALL).group()
    logging.info(f"Extracted dictionary string: {dict_string}")

    logging.info("Parsing string to dictionary...")
    try:
        message_dict = json.loads(dict_string)
        logging.info("String successfully parsed to dictionary.")
    except json.JSONDecodeError as e:
        logging.error(f"Error in parsing the response: {str(e)}")
        logging.error(f"Response content: {dict_string}")
        message_dict = {}

    return message_dict
