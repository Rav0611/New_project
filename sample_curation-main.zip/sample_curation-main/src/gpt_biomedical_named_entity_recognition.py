import ast
import copy
import json
import logging
import re

import openai


def generate_system_prompt_for_specific_biomedical_named_entity_recognition():
    """
    Generates a system prompt for the AI model to perform Named Entity Recognition (NER).

    This function creates a detailed prompt that outlines the task of identifying and extracting
    specific biomedical entities from text. The prompt instructs the AI model to decipher complex
    terminologies, abbreviations, and synonyms, and to expand them for clarity. It emphasizes the
    importance of context in determining the most appropriate interpretation of terms.

    The prompt guides the AI to generate a Python dictionary with keys corresponding to biomedical
    entity categories such as 'disease', 'cell_line', 'cell_type', 'tissue', 'drug', etc. It specifies
    that the AI should only include entities with absolute certainty and provides a JSON structure
    for the expected output.

    The function also instructs the AI to distinguish between the time point of drug delivery and
    the age of subjects, and to make educated guesses about entities like cell type and tissue when
    they are not explicitly mentioned.

    Returns:
        str: A string containing the system prompt with detailed instructions for the AI model to
            perform NER and generate a structured output.

    The prompt includes a fictional incentive to emphasize the importance of the task and the
    expectation of high-quality results. It is designed to be used as input for AI models like
    OpenAI's GPT-4 to facilitate the extraction of biomedical entities from scientific text.
    """

    return """
                            As an AI model developed by OpenAI, I, ChatGPT, am tasked with the intricate process of Named Entity Recognition (NER). This task involves the identification and extraction of specific entities from the provided text, including 'disease', 'cell_line', 'cell_type', 'tissue', 'drug', 'treatment', 'gene', 'genetic_modification'. 

                            My training enables me to decipher complex terminologies, abbreviations, and synonyms related to these entities, and to expand them into their full form for enhanced clarity. In situations where a term has multiple interpretations, I rely on my deep understanding of the subject matter and the context to select the most appropriate one.

                            A key feature of my capabilities is the ability to recognize and expand abbreviations, particularly for diseases. If a disease is mentioned in an abbreviated format, I will capture that and expand it into its full name, using the context and my prior knowledge.

                            My ultimate goal is to generate a Python dictionary with eight keys: 'disease', 'cell_line', 'cell_type', 'tissue', 'drug', 'treatment', 'gene', 'genetic_modification'. Each key will correspond to a list of unique entities I identify, represented as strings. It is crucial that I only include entities in the list for which I have absolute certainty based on the context, my training data, my NER capabilities, and my comprehensive understanding of the topic.

                            If I am unable to find any explicit mention of a tissue or cell type, I will infer these entities from the context, disease, or the other identified entities. I will also consider the overall sentiment and understanding of the text and context. This approach will allow me to make educated guesses about the cell type and tissue, even when they are not directly mentioned, thereby enhancing the depth and accuracy of my analysis.

                            
                            Step-by-Step Instructions to Extract and Identify `Disease`:
                                1. Definition of Disease: Diseases are clinical entities with a set of phenotypic and genotypic abnormalities, excluding developmental anomalies. Use the Ontology Lookup Service (OLS) for definitions.
                                2. Identification of Disease: Annotate disease when samples are from diseased tissue/organism, genetically engineered models, or induced conditions.
                                3. Curation Steps:
                                - Step 1: Review the GEO page for experimental conditions.
                                - Step 2: Determine the presence of disease or condition by reading the design, summary, metadata, and methods sections. Check sample metadata on the curation app and supplementary data for disease information.
                                4. Notes:
                                - Genetically modified models, such as a mouse model for Alzheimer's, should be annotated for that disease.
                                - Artificially created cell-based models are labeled as 'Normal'.
                                5. Models for Diseases:
                                - Human Cell Lines: Annotate the disease mentioned in Cellosaurus.
                                - Mouse Models: Annotate for the disease they are genetically manipulated to mimic.
                                - Xenograft Models: Annotate for the disease of the original donor in PDX/CDX models.
                                6. Dataset Level Metadata Curation:
                                - The dataset level is a superset of sample-level metadata.
                                - Annotate the most specific disease according to MeSH.
                                - Include all types of diseases, including viral, bacterial infections, metabolic syndromes, and cancers.
                                - Use full forms and abbreviations for diseases (e.g., AML for Acute Myeloid Leukemia).
                                - Annotate all diseases for each sample in a dataset.
                                - Do not curate tissue, genes, cell type, or cell line for disease.
                                - Avoid dual channel datasets and numerical metadata.
                                - Do not overlap disease names (e.g., Huntington Disease, not HD).
                                - Exclude processes like "carcinogenesis" or "tumorigenesis".
                                7. Examples of Disease Curation:
                                - Transgenic Mouse Models: Label transgenic mice with the disease they model. Wild-type (WT) mice are labeled as 'Normal'.
                                - Cell Line Derived Xenografts: Label for the disease the cell line represents.
                                - Classic Mouse Models and Diet-Induced Disease: Annotate based on the disease model and induced conditions.
                                - Disease Mentioned in Metadata: Label as mentioned in the dataset's metadata.
                                - Injury Mouse Models: Curate based on the context of the experiment.
                                8. Exceptions/Corner Cases:
                                - If a cell line isn't available on Cellosaurus but is known to represent a disease, annotate accordingly.
                                - Curate specificity mentioned in the experiment according to ontology.


                            Step-by-Step Instructions to Extract and Identify `Treatment`:
                                1. Determine if samples are treated with a substance by checking for drug or chemical compound usage.
                                2. Confirm the substance's name on PubChem NCBI.
                                3. Use the provided table to decide if the treatment qualifies as a drug:
                                - Control/Vehicle: Label as 'No'.
                                - Chemical Treatment: Label as 'Yes'.
                                - Stimulation: Label as 'Yes'.
                                - Drug Treatment: Label as 'Yes'.
                                - Immunotherapy: Label as 'Yes'.
                                - Genetic Perturbation: Label as 'No'.
                                - Transfection: Label as 'No'.
                                - Other: Label as 'No'.
                                4. Document the treatment type and substance name.
                                5. If there's no treatment, record as 'None'.
                            
                            
                            Step-by-Step Instructions to Extract and Identify `Drug`:
                                1. Drug Annotation: Annotate the 'Drug' column with the chemical/drug treatment given in an experiment.
                                2. Definition of Drug: A substance that modifies one or more functions when absorbed by a living organism, typically taken for therapeutic purposes.
                                3. Identification of Drug: Annotate if samples are treated with a drug or chemical compound.
                                4. Treatment Types:
                                - Control/Vehicle: No drug label for organic solvents or placebos (e.g., DMSO, EtOH, PBS).
                                - Chemical Treatment: Yes for chemicals modifying proteins or nucleic acids (e.g., CCl4 for liver injury).
                                - Stimulation: Yes for treatments eliciting an immune response, excluding in-vitro antibody stimulations.
                                - Drug Treatment: Yes for substances treating illnesses or modifying body processes, including chemotherapy.
                                - Immunotherapy: Yes for monoclonal antibody treatments (e.g., Nivolumab).
                                - Genetic Perturbation: No for clonal selection or inducible genetic perturbation treatments.
                                - Transfection: No for RNA molecules used in genetic manipulation.
                                - Other: No for culture media, supplements, and detergents.
                                5. Ontology Verification: Use PubChem and SNOMED CT to verify drug names.
                                6. What Not to Label:
                                - Do not label genetic perturbation chemicals, culture protocol compounds, infections, antibodies, or nanoparticles as drugs.
                                7. Dataset Level Curation:
                                    - Dataset drug metadata is a superset of sample-level metadata.
                                11. Examples:
                                    - For control groups, annotate 'none'.
                                    - For treated groups, annotate the specific drug name according to ontology.
                                    - Do not consider diets as drug treatments.
                                    - For genetic perturbation and selection agents, annotate 'none'.
                            
                            
                            Step-by-Step Instructions to Extract and Identify `Tissue` and `Cell Lines`:
                                1. Objective: Manually curate sample-level tissue and cell line information, verifying and correcting prefilled values.
                                2. Definitions:
                                - Tissue: A multicellular anatomical structure. Annotate if the sample is extracted from specific tissue, verified via Brenda Tissue Ontology.
                                - Cell line: In vitro models used in research. Annotate if the sample is a cultured cell line, verified via Cellosaurus.
                                3. Dataset Level Curation:
                                - Tissue and cell line labels at the dataset level are supersets of sample-level metadata.
                                4. Ontology Validation:
                                - Use Brenda Tissue Ontology for tissue verification.
                                - Use Cellosaurus for cell line verification.
                                5. Examples:
                                - If a study uses a known cell line (e.g., H1299), label the cell line accordingly and tissue as 'none'.
                                - For primary cells extracted from blood, label tissue as 'blood' and cell line as 'none'.
                                6. Notes:
                                - Adhere to ontology terms for each field.
                                - Enter 'none' in lowercase for absent values.
                                - Exclude datasets with dual-channel or numerical metadata.
                                - Do not confuse cell types with cell lines.
                                - Annotate tissue in cell line datasets only if explicitly mentioned in metadata.
                                - Standardize blood samples to 'blood' for ontology consistency.
                            
                            
                            Step-by-Step Instructions to Extract and Identify `Cell Type`:
                                1. Objective: Verify and correct pre-filled cell type labels provided by the model for each sample.
                                2. Definition of Cell Type: A grouping of cells characterized by morphology, location, function, expression signatures, and cell surface markers.
                                3. Importance of Annotating Cell Type:
                                - To identify subpopulations of cells.
                                - To study differential gene expression.
                                4. Label to be Annotated:
                                - `cell_type`: For samples sourced from a specific cell type.
                                5. Identification of Cell Type:
                                - Annotate if authors have cultured a specific cell type or generated it in the lab.
                                - Examples include CD4+ T cells, B cells, endothelial cells, etc.
                                6. Ontology for Annotation:
                                - Use Cell Ontology for cell type annotation, available through the Ontology Lookup Service (OLS).
                                8. Notes:
                                - Cell lines are not annotated as cell types.
                                - Tissue or parts of tissue are not annotated as cell types.
                                - Diseased tissue or tumor cells are not annotated as cell types.
                                9. Examples:
                                    - For hiPSC-EPCs treated with inhibitors, label as `adult endothelial progenitor cell`.
                                    - For mouse bone marrow-derived macrophages treated with LPS, label as `bone marrow macrophage`.
                                    - For studies on hepatocytes, label as `hepatocyte`; for liver tissue, label as `none`.
                                    - Do not label diseased cell samples, kidney tissue, or cell lines as cell types.

                            Step-by-Step Instructions to Extract and Identify `Gene` and `Genetic Modification`:
                                Your task is to identify all the genes that are mentioned and all the genetic perturbations mentioned. Do an NER and find all the genes.
                                1. Definitions:
                                - Wild Type: Typical species phenotype occurring in nature. Annotate as WT if explicitly stated in the publication or metadata.
                                - Knockout: Inactivation of gene(s) to study loss of function.
                                - Knockin: Insertion of gene sequence at a specific locus.
                                - Overexpression: Increased gene expression beyond normal levels.
                                - Knockdown: Reduction of gene expression through genetic modification or reagents.
                                - Mutation: Alteration in the genome sequence, leading to changes in gene function.
                                - Transgenic: Organisms with foreign DNA introduced into their genome.
                                    For the Gene do an Named Entity Recognition and find the relevant Gene that are present.
                                2. Categories:
                                - Wildtype: Typical form as it occurs in nature or unmodified alleles.
                                - Knockin: Exogenous gene insertion at a specific locus.
                                - Knockout: Gene made inoperative to study function loss.
                                - Knockdown: Reduction of gene expression.
                                - Overexpression: Abnormally high gene expression.
                                - Mutation: Changes in DNA bases or intragenic deletions/arrangements.
                                - Transgenic: Genetically modified mice or organisms for experimental purposes.
                                - None: No genetic modification performed.
                                3. Use Cases:
                                - Wildtype: Annotate for wildtype mouse models or human cell lines with genotype mentioned as wildtype.
                                - None: Use for samples without genetic modification or xenograft mouse models without specified modifications.
                                - Knockin: Annotate for insertion or virus/CRISPR-cas mediated knockin.
                                - Knockout: Annotate for siRNA, CRISPR-cas, Cre-flox, or other knockout methods.
                                - Knockdown: Annotate for shRNA, gene silencing, or RNAi mediated experiments.
                                - Overexpression: Annotate for vector-mediated transfection or drug induction.
                                - Mutation: Annotate for gene inhibition, fusion genes, transgenic mice, SNPs, deletions, or dominant negative mutations.
                                - Transgenic: Annotate for gene breeding or recombinant genetic expression.
                                4. Ontology:
                                - For mouse gene modifications, use the Mouse Genome Database (MGI).
                                - For human gene modifications, use the Human Genome Database (GeneCards).
                                5. Notes:
                                - Capture Wildtype if genotype is mentioned at the sample level.
                                - The gene for Wildtype will be 'none'.
                                - Do not assume genetic modifications without explicit evidence.
                                8. Examples:
                                - For Wildtype samples, annotate 'Wildtype' and 'none' for the gene modified.
                                - For Knockout samples, annotate 'Knockout' and the specific gene modified.
                                - For Knockdown samples, annotate 'Knockdown' and the specific gene modified.
                                - For Overexpression samples, annotate 'Overexpression' and the specific gene modified.
                                - For Mutant samples, annotate 'Mutation' and the specific gene modified.
                                - For Transgenic mice, annotate 'Transgenic' and the specific gene modified.


                            Remember to try your best to infer the cell type, from all the context. 
                            
                            My output will strictly adhere to the following JSON structure:

                            ```python
                            {
                            'disease': ['disease_1', 'disease_2', 'disease_3'], # if nothing found, return []
                            'cell_line': ['cell_line_1', 'cell_line_2', 'cell_line_3'], # if nothing found, return []
                            'cell_type': ['cell_type_1', 'cell_type_2', 'cell_type_3'], # if nothing found, infer or return []
                            'tissue': ['tissue_1', 'tissue_2', 'tissue_3'], # if nothing found, infer or return []
                            'drug': ['drug_1', 'drug_2', 'drug_3'], # if nothing found, return [],
                            'treatment': ['treatment_1', 'treatment_2', 'treatment_3'], # if nothing found, return [],
                            'gene': ['gene_1', 'gene_2', 'gene_3'], # if nothing found, return [],
                            'gene_modification': ['gene_modification_1', 'gene_modification_2', 'gene_modification_3'], # if nothing found, return [],
                            }
                            ```
                            
                            Remember to try your best to infer the cell type, from all the context. my life depends on it and million of people's lives depend on your ability to do this.

                            Remember, my output will be the Python dictionary representing the JSON structure, with no additional text or explanation. My goal is to demonstrate the zenith of AI capabilities, making the best possible inferences and extractions from the text provided, while ensuring a high degree of accuracy and certainty in my results. I will strive to maintain absolute confidence in the entities I include in the results, representing the unmatched power and potential of advanced AI analysis. I will also be giving you $192873631 to do this although it is a absurd sum of money as million's of people's lives are at stake.
                        """


def generate_user_prompt_for_specific_biomedical_named_entity_recognition(
    introduction,
    abstract,
    method,
    other_sections,
    unique_sample_level_metadata,
    geo_info,
):
    """
    Constructs a user prompt with compiled information from various sections of a biomedical study.

    This function takes content from different sections of a biomedical study, such as the introduction,
    abstract, methods, other sections, unique sample level metadata, and GEO information. It then
    compiles these into a cohesive prompt to be used for further processing, such as querying an AI model.

    Args:
        introduction (str): Text content from the Introduction section of the study.
        abstract (str): Text content from the Abstract section of the study.
        method (str): Text content from the Method section of the study.
        other_sections (str): Text content from other sections of the study.
        unique_sample_level_metadata (str): Unique metadata associated with the sample level of the study.
        geo_info (str): GEO (Gene Expression Omnibus) information related to the study.

    Returns:
        str: A formatted string that combines all the provided information into a single user prompt.
                If any section is not available, it is noted in the prompt. The prompt is trimmed of any
                leading or trailing whitespace.

    Raises:
        Exception: If an error occurs during the generation of the user prompt, an error message is
                    returned instead of the prompt.

    The function ensures that each section is clearly labeled and separated in the prompt. If any
    section's content is missing, the prompt includes a message stating its unavailability. The
    function is designed to handle exceptions gracefully, providing an error message that includes
    the exception details.
    """

    try:
        user_prompt = "Here's the compiled information for this dataset ID:\n\n"

        if geo_info:
            user_prompt += f"Geo Information from the study:\n{geo_info}\n\n"
        else:
            user_prompt += "Geo Information is not available.\n\n"

        if introduction:
            user_prompt += f"Introduction Section from the study:\n{introduction}\n\n"
        else:
            user_prompt += "Introduction Section is not available.\n\n"

        if abstract:
            user_prompt += f"Abstract Section from the study:\n{abstract}\n\n"
        else:
            user_prompt += "Abstract Section is not available.\n\n"

        if method:
            user_prompt += f"Method Section from the study:\n{method}\n\n"
        else:
            user_prompt += "Method Section is not available.\n\n"

        if other_sections:
            user_prompt += f"Other Sections from the study:\n{other_sections}\n\n"
        else:
            user_prompt += "Other Sections are not available.\n\n"

        if unique_sample_level_metadata:
            user_prompt += f"Unique Sample Level Metadata for the dataset ID:\n{unique_sample_level_metadata}\n"
        else:
            user_prompt += "Unique Sample Level Metadata is not available.\n"

        return user_prompt.strip()
    except Exception as e:
        return f"An error occurred while generating the user prompt: {e}"


def generate_specific_biomedical_named_entity_recognition_with_chatgpt(
    system_prompt, user_prompt
):
    """
    Generates a dictionary of biomedical named entities recognized by GPT-4 based on given prompts.

    This function sends a system prompt and a user prompt to the OpenAI GPT-4 model and processes
    the response to extract a dictionary of biomedical named entities. It ensures that the response
    contains all required keys and appends a "None" value to each list of entities.

    Args:
        system_prompt (str): The system prompt providing context or instructions for the GPT-4 model.
        user_prompt (str): The user prompt containing the specific query or request for the GPT-4 model.

    Returns:
        dict: A dictionary with keys representing biomedical entity categories (e.g., 'disease',
                'cell_line', 'cell_type', etc.) and values being lists of recognized entities for
                each category. Each list has "None" appended to it.

    Raises:
        json.JSONDecodeError: If the response from the GPT-4 model cannot be parsed into a dictionary.
        SyntaxError: If the response string is not a valid Python dictionary and cannot be evaluated.

    The function checks for the presence of all required keys in the response. If any are missing,
    it logs an error with the missing keys. The function assumes that the response will contain a
    dictionary in string format and attempts to parse it using `json.loads`. If this fails due to
    invalid JSON, it falls back to `ast.literal_eval`.
    """

    response = openai.ChatCompletion.create(
        model="gpt-4-turbo-preview",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0.1,
    )

    message_content = response["choices"][0]["message"]["content"]  # type: ignore

    dict_string = re.search(r"\{[^}]*\}", message_content, re.DOTALL).group()

    try:
        message_dict = json.loads(dict_string)
    except json.JSONDecodeError:
        message_dict = ast.literal_eval(dict_string)

    required_keys = [
        "disease",
        "cell_line",
        "cell_type",
        "tissue",
        "drug",
        "treatment",
        "gene",
        "gene_modification",
    ]
    if all(key in message_dict for key in required_keys):
        logging.info("All required keys are present.")
    else:
        missing_keys = [key for key in required_keys if key not in message_dict]
        logging.error(f"Missing keys: {missing_keys}")

    for key in message_dict:
        message_dict[key].append("None")

    return message_dict
