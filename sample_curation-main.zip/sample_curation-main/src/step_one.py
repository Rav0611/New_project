# Standard library imports
import argparse
import json
import os
import sys
import time
import warnings
import xml.etree.ElementTree as ET

# Third-party imports
import pandas as pd
import requests
from Bio import Entrez
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Suppress warnings
warnings.filterwarnings("ignore")

# Modify the system path to include the scrapemed directory
sys.path.insert(0, "../../scrapemed")

# Local application imports
import scrapemed.paper as paper

from utils.fetch_dataset_and_unique_sample_metadata_values import (
    fetch_dataset_and_unique_sample_metadata_values,
)
from utils.fetch_pmc_ids import fetch_pmc_ids
from utils.get_geo_page_information import (
    fetch_geo_info_from_ncbi,
    fetch_geo_overall_design,
)

# Retrieve the OpenAI key from environment variables
openai_key = os.getenv("OPENAI_KEY")

# Argument parsing for command-line utility
parser = argparse.ArgumentParser(description="Process some dataset IDs.")
parser.add_argument(
    "file_path", type=str, help="Location of the file containing the dataset IDs"
)

args = parser.parse_args()

with open(args.file_path, "r") as file:
    process_dataset_ids = json.load(file)


def process_dataset_and_save(dataset_ids):
    base_dir = f"/app/data/dataset_info/"
    os.makedirs("/app/data", exist_ok=True)
    os.makedirs(base_dir, exist_ok=True)
    os.makedirs("/app/data/raw_sample_level_metadata/", exist_ok=True)
    os.makedirs("/app/data/unique_sample_metadata/", exist_ok=True)

    query_term = " OR ".join(dataset_ids)
    handle = Entrez.esearch(db="gds", term=query_term, retmax=10 ** 5)
    record = Entrez.read(handle)

    i = ",".join(record["IdList"])

    h2 = Entrez.esummary(db="gds", id=i)
    r2 = Entrez.read(h2)
    pmid_dict = {}
    for d in r2:
        series = d["Accession"]
        if "GSE" in series:
            pmid_dict[series] = d["PubMedIds"]

    pmid_dict_converted = {
        gse: [int(elem) for elem in pmid_list] for gse, pmid_list in pmid_dict.items()
    }
    pubmed_ids_list = list(
        set(
            [
                pubmed_id
                for sublist in pmid_dict_converted.values()
                for pubmed_id in sublist
            ]
        )
    )

    master_pmc_ids = {}

    for pubmed_id in pubmed_ids_list:
        pmc_id_dict = fetch_pmc_ids([pubmed_id], batch_size=1, retries=3, delay=0.5)
        master_pmc_ids.update(pmc_id_dict)
        pid = str(pubmed_id)
        print(f"Fetched PMC ID for PubMed ID {pid}: {pmc_id_dict[pid]}")

    gse_pubmed_list = [
        (gse, pmid) for gse, pmids in pmid_dict_converted.items() for pmid in pmids
    ]

    phase_two_data_audit_owkin = pd.DataFrame(
        gse_pubmed_list, columns=["gse_id", "pubmed_id"]
    )

    def get_pmcid(pubmed_id):
        return master_pmc_ids.get(str(pubmed_id))

    phase_two_data_audit_owkin["pmcid"] = phase_two_data_audit_owkin["pubmed_id"].apply(
        get_pmcid
    )

    phase_two_data_audit_owkin = phase_two_data_audit_owkin.groupby("gse_id").agg(
        {"pubmed_id": list, "pmcid": list}
    )

    data_to_save = phase_two_data_audit_owkin["pmcid"].to_dict()
    file_path = "/app/data/dataset_info/paper_mappings.json"
    with open(file_path, "w") as json_file:
        json.dump(data_to_save, json_file)

    pmc_ids = phase_two_data_audit_owkin["pmcid"].explode().tolist()
    if pmc_ids is not None:
        for pmc_id in pmc_ids:
            try:
                pmc_id_number = int(pmc_id)
                email = "rajdeep.mondal@elucidata.io"
                paper_info = {}

                try:
                    p_obj = paper.Paper.from_pmc(pmc_id_number, email, download=True)
                except requests.RequestException as e:
                    print(f"HTTP request error for PMC ID {pmc_id}: {e}")
                    continue
                except ET.ParseError as e:
                    print(f"XML parsing error for PMC ID {pmc_id}: {e}")
                    continue
                except Exception as e:
                    print(
                        f"An error occurred while fetching paper for PMC ID {pmc_id}: {e}"
                    )
                    continue

                if p_obj.body:
                    paper_info["result"] = {}
                    paper_info["abstract"] = {}
                    paper_info["method"] = {}
                    paper_info["introduction"] = {}
                    paper_info["resource"] = {}
                    paper_info["others"] = {}

                    for section in p_obj.body:
                        try:
                            section_title = section.title.lower()
                            section_text = (
                                section.get_section_text()
                                .encode("utf-8")
                                .decode("utf-8")
                            )

                            if "result" in section_title:
                                paper_info["result"][section.title] = section_text

                            elif "abstract" in section_title:
                                paper_info["abstract"][section.title] = section_text

                            elif "method" in section_title:
                                paper_info["method"][section.title] = section_text

                            elif "intro" in section_title:
                                paper_info["introduction"][section.title] = section_text

                            elif "data" in section_title or "code" in section_title:
                                paper_info["resource"][section.title] = section_text

                            elif any(
                                x in section_title
                                for x in ["supplementary", "acknowledge", "reference"]
                            ):
                                continue

                            else:
                                paper_info["others"][section.title] = section_text

                        except AttributeError as e:
                            print(
                                f"Missing attribute while processing section for PMC ID {pmc_id}: {e}"
                            )
                        except Exception as e:
                            print(
                                f"An error occurred while processing section for PMC ID {pmc_id}: {e}"
                            )

                json_path = f"{base_dir}{pmc_id}.json"

                try:
                    with open(json_path, "w", encoding="utf-8") as json_file:
                        json.dump(paper_info, json_file, ensure_ascii=False, indent=4)
                except IOError as e:
                    print(f"File I/O error for PMC ID {pmc_id}: {e}")
                except Exception as e:
                    print(
                        f"An error occurred while writing to file for PMC ID {pmc_id}: {e}"
                    )
                time.sleep(1)
                print(f"{pmc_id} done.")
            except ValueError as e:
                print(f"Value error for PMC ID {pmc_id}: {e}")
            except Exception as e:
                print(f"An unexpected error occurred for PMC ID {pmc_id}: {e}")

    for dataset_id in dataset_ids:
        raw_sample_level_metadata, cleaned_unique_sample_metadata = fetch_dataset_and_unique_sample_metadata_values(dataset_id)
        raw_metadata_path = (
            f"/app/data/raw_sample_level_metadata/{dataset_id}.csv"
        )
        geo_info_path = f"/app/data/geo_info/{dataset_id}.txt"
        unique_metadata_path = (
            f"/app/data/unique_sample_metadata/{dataset_id}.json"
        )

        os.makedirs(os.path.dirname(raw_metadata_path), exist_ok=True)
        os.makedirs(os.path.dirname(geo_info_path), exist_ok=True)
        os.makedirs(os.path.dirname(unique_metadata_path), exist_ok=True)

        raw_sample_level_metadata.to_csv(raw_metadata_path)

        geo_info = fetch_geo_info_from_ncbi(dataset_id) or ""
        geo_design = fetch_geo_overall_design(dataset_id) or ""
        with open(geo_info_path, "w", encoding="utf-8") as file:
            file_contents = "\n".join(filter(None, [geo_info, geo_design]))
            file.write(file_contents)

        with open(unique_metadata_path, "w", encoding="utf-8") as json_file:
            json.dump(cleaned_unique_sample_metadata, json_file, indent=4)

process_dataset_and_save(process_dataset_ids)
