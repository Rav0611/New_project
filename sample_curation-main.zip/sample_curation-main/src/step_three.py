# Standard library imports
import argparse
import json
import os
import warnings

# Third-party imports
import numpy as np
import pandas as pd
from dotenv import load_dotenv

# Local application imports
from ontology_mapper.model import Mention
from ontology_mapper.normalize_standard_fields import _normalize_
from utils.upload_polly_workspace import Workspaces

# Load environment variables and suppress warnings
load_dotenv()
warnings.filterwarnings("ignore")

# Initialize workspace and other configurations
token = os.getenv("POLLY_TOKEN")
workspace_id = int(os.getenv("WORKSPACE_ID"))
workspaces = Workspaces(token)

# Argument parsing for command-line utility
parser = argparse.ArgumentParser(description="Process some dataset IDs.")
parser.add_argument(
    "file_path", type=str, help="Location of the file containing the dataset IDs"
)
args = parser.parse_args()

tissue_keywords = []
disease_keywords = []
cell_line_keywords = []
cell_type_keywords = []
folder = "/app/results"
data_dict = {}

with open(args.file_path, "r") as file:
    process_dataset_ids = json.load(file)

for dataset_id in os.listdir(folder):
    if dataset_id in process_dataset_ids:
        dataset_path = os.path.join(folder, dataset_id)
        if os.path.isdir(dataset_path):
            for file in os.listdir(dataset_path):
                if "step_three_curated_sample_level_metadata" in file:
                    try:
                        data_path = os.path.join(dataset_path, file)
                        df = pd.read_csv(data_path)
                        df.replace("None", np.nan, inplace=True)
                        df = df.dropna(how="all")
                        df.replace(np.nan, "None", inplace=True)
                        if "GSM_ID" in df.columns:
                            df.set_index("GSM_ID", inplace=True)
                        data_dict[dataset_id] = df
                    except Exception as e:
                        print(f"Cannot read file: {e}")
print(data_dict)
try:
    for dataset_id in process_dataset_ids:
        dataset = data_dict.get(dataset_id, {})
        tissue_keywords.extend(dataset.get("gpt_tissue", []))
        disease_keywords.extend(dataset.get("gpt_disease", []))
        cell_line_keywords.extend(dataset.get("gpt_cell_line", []))
        cell_type_keywords.extend(dataset.get("gpt_cell_type", []))
except NameError as e:
    print(f"A NameError occurred: {e}")
except AttributeError as e:
    print(f"An AttributeError occurred: {e}")
except Exception as e:
    print(f"An unexpected error occurred: {e}")

tissue_keywords = [keyword for keyword in set(tissue_keywords) if keyword != "None"]
disease_keywords = [keyword for keyword in set(disease_keywords) if keyword != "None"]
cell_line_keywords = [
    keyword for keyword in set(cell_line_keywords) if keyword != "None"
]
cell_type_keywords = [
    keyword for keyword in set(cell_type_keywords) if keyword != "None"
]

print('before curation')
print(tissue_keywords)
print(disease_keywords)
print(cell_line_keywords)
print(cell_type_keywords)


ontology_mapping_structured_data = [
    Mention(
        keywords=tissue_keywords,
        entity_type="tissue",  # type: ignore
        ontology="BTO",
        topk=10,
    ),
    Mention(
        keywords=disease_keywords,
        entity_type="disease",  # type: ignore
        ontology="MONDO",
        topk=10,
    ),
    Mention(
        keywords=cell_line_keywords,
        entity_type="cell_line",  # type: ignore
        ontology="",
        topk=10,
    ),  # type: ignore
    Mention(
        keywords=cell_type_keywords,
        entity_type="cell_type",  # type: ignore
        ontology="CELL",
        topk=10,
    ),
]

ontology_mapping_results = _normalize_(ontology_mapping_structured_data)

print(ontology_mapping_results)

ontology_mapped_tissue = ontology_mapping_results["tissue"]
ontology_mapped_disease = ontology_mapping_results["disease"]
ontology_mapped_cell_line = ontology_mapping_results["cell_line"]
ontology_mapped_cell_type = ontology_mapping_results["cell_type"]

ontology_mapping_results = {
    "tissue": ontology_mapped_tissue,
    "disease": ontology_mapped_disease,
    "cell_line": ontology_mapped_cell_line,
    "cell_type": ontology_mapped_cell_type,
}

print(ontology_mapping_results)

def extract_normalized_tags(data_dict):
    if not data_dict:
        return {}
    return {key: value.get("normalised_tag") if isinstance(value, dict) else value for key, value in data_dict.items()}


ontology_mapped_tags_cell_type = extract_normalized_tags(ontology_mapped_cell_type)
ontology_mapped_tags_disease = extract_normalized_tags(ontology_mapped_disease)
ontology_mapped_tags_tissue = extract_normalized_tags(ontology_mapped_tissue)
ontology_mapped_tags_cell_line = ontology_mapped_cell_line

ontology_mappings = {
    key: value for key, value in {
        "gpt_disease": ontology_mapped_tags_disease,
        "gpt_tissue": ontology_mapped_tags_tissue,
        "gpt_cell_line": ontology_mapped_tags_cell_line,
        "gpt_cell_type": ontology_mapped_tags_cell_type,
    }.items() if value
}

print(ontology_mapped_tags_disease)
print(ontology_mapped_tags_tissue)
print(ontology_mapped_tags_cell_line)
print(ontology_mapped_tags_cell_type)

for dataset_id in data_dict:
    if not data_dict[dataset_id].empty:
        print(dataset_id)
        print(data_dict[dataset_id])
        for category, mapping in ontology_mappings.items():
            if category in data_dict[dataset_id].columns:
                data_dict[dataset_id][category] = (
                    pd.Series(data_dict[dataset_id][category])
                    .map(mapping)
                    .fillna(data_dict[dataset_id][category])
                )
        
for dataset_id, dataframe in data_dict.items():
    if not data_dict[dataset_id].empty:
        ontology_mapped_sample_level_metadata_path = f"/app/results/{dataset_id}/{dataset_id}_curated_and_ontology_mapped_final_sample_level_metadata.csv"
        os.makedirs(
            os.path.dirname(ontology_mapped_sample_level_metadata_path), exist_ok=True
        )
        dataframe.to_csv(ontology_mapped_sample_level_metadata_path)
        workspaces.upload_to_workspaces(
            workspace_id=workspace_id,
            workspace_path=f"polly://curation_output/{dataset_id}/{dataset_id}_curated_and_ontology_mapped_final_sample_level_metadata.csv",
            local_path=ontology_mapped_sample_level_metadata_path,
        )
